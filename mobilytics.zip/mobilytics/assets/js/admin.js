( function () {
	'use strict';

	if ( typeof MobilyticsAdmin === 'undefined' ) return;

	var runBtn      = document.getElementById( 'mobilytics-run-audit' );
	var progressBox = document.getElementById( 'mobilytics-progress' );
	var progressText= document.getElementById( 'mobilytics-progress-text' );
	var errorBox    = document.getElementById( 'mobilytics-error' );
	var resultsRoot = document.getElementById( 'mobilytics-results-root' );
	var lastScanTime= document.getElementById( 'mobilytics-last-scan-time' );

	function setRunning( isRunning ) {
		runBtn.disabled = isRunning;
		runBtn.querySelector( '.mobilytics-spin-icon' ).style.display = isRunning ? 'inline-block' : 'none';
		runBtn.querySelector( '.mobilytics-run-label' ).textContent = isRunning ? MobilyticsAdmin.i18n.running : MobilyticsAdmin.i18n.runAudit;
		progressBox.style.display = isRunning ? 'flex' : 'none';
	}

	function showError( message ) {
		errorBox.style.display = 'block';
		errorBox.querySelector( 'p' ).textContent = message || MobilyticsAdmin.i18n.error;
	}

	function hideError() {
		errorBox.style.display = 'none';
	}

	function post( action, data ) {
		var form = new FormData();
		form.append( 'action', action );
		form.append( 'nonce', MobilyticsAdmin.nonce );
		Object.keys( data || {} ).forEach( function ( key ) {
			form.append( key, data[ key ] );
		} );
		return fetch( MobilyticsAdmin.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: form } )
			.then( function ( r ) { return r.json(); } );
	}

	/**
	 * Runs the client-side geometry scan inside a hidden iframe pointed at
	 * the live front-end page (with a one-time scan token in the query
	 * string), and resolves with the results posted back via postMessage.
	 */
	function runClientScan( iframeUrl, token ) {
		return new Promise( function ( resolve ) {
			var timeout;
			var iframe = document.createElement( 'iframe' );
			iframe.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:375px;height:812px;border:0;visibility:hidden;';

			function cleanup() {
				window.removeEventListener( 'message', onMessage );
				clearTimeout( timeout );
				if ( iframe.parentNode ) iframe.parentNode.removeChild( iframe );
			}

			function onMessage( event ) {
				var data = event.data;
				if ( ! data || ! data.mobilytics || data.token !== token ) return;
				cleanup();
				resolve( data.results || [] );
			}

			window.addEventListener( 'message', onMessage );

			// Safety net: if the frontend never responds (blocked by a
			// security plugin, cache, etc.), don't hang the whole audit —
			// resolve with an empty client-check set after 12s.
			timeout = setTimeout( function () {
				cleanup();
				resolve( [] );
			}, 12000 );

			iframe.src = iframeUrl;
			document.body.appendChild( iframe );
		} );
	}

	function runFullAudit() {
		hideError();
		setRunning( true );
		progressText.textContent = MobilyticsAdmin.i18n.running;

		post( 'mobilytics_start_scan', { url: MobilyticsAdmin.scanUrl } )
			.then( function ( res ) {
				if ( ! res.success ) {
					throw new Error( res.data && res.data.message ? res.data.message : MobilyticsAdmin.i18n.error );
				}
				var data = res.data;
				progressText.textContent = MobilyticsAdmin.i18n.loadingClient;
				return runClientScan( data.scan_iframe_url, data.scan_token ).then( function ( clientChecks ) {
					return post( 'mobilytics_finish_scan', {
						url: data.url,
						token: data.scan_token,
						server_checks: JSON.stringify( data.server_checks ),
						client_checks: JSON.stringify( clientChecks ),
					} );
				} );
			} )
			.then( function ( res ) {
				if ( ! res.success ) {
					throw new Error( res.data && res.data.message ? res.data.message : MobilyticsAdmin.i18n.error );
				}
				renderResults( res.data );
				lastScanTime.textContent = res.data.timestamp;
			} )
			.catch( function ( err ) {
				showError( err.message );
			} )
			.finally( function () {
				setRunning( false );
			} );
	}

	// -----------------------------------------------------------------
	// Rendering (mirrors the PHP template so re-scans update instantly
	// without a full page reload).
	// -----------------------------------------------------------------

	function esc( str ) {
		var div = document.createElement( 'div' );
		div.textContent = str == null ? '' : String( str );
		return div.innerHTML;
	}

	function scoreClass( score ) {
		if ( score >= 80 ) return 'good';
		if ( score >= 50 ) return 'warning';
		return 'critical';
	}

	function renderResults( record ) {
		var score = record.score.overall_score;
		var grade = record.score.grade;
		var counts = record.score.counts;
		var cats = record.score.categories;
		var cls = scoreClass( score );
		var circumference = 326.7;

		var html = '';
		html += '<div class="mobilytics-score-section">';
		html += '  <div class="mobilytics-score-hero mobilytics-score-hero--' + cls + '">';
		html += '    <div class="mobilytics-score-circle">';
		html += '      <svg viewBox="0 0 120 120" class="mobilytics-score-ring">';
		html += '        <circle cx="60" cy="60" r="52" class="mobilytics-ring-bg" />';
		html += '        <circle cx="60" cy="60" r="52" class="mobilytics-ring-fg mobilytics-ring-fg--' + cls + '" stroke-dasharray="' + ( circumference * score / 100 ).toFixed( 1 ) + ' ' + circumference + '" />';
		html += '      </svg>';
		html += '      <div class="mobilytics-score-number"><strong>' + score + '</strong><span>/100</span></div>';
		html += '    </div>';
		html += '    <div class="mobilytics-score-meta">';
		html += '      <div class="mobilytics-score-grade mobilytics-badge mobilytics-badge--' + grade.status + '">' + esc( grade.label ) + '</div>';
		html += '      <div class="mobilytics-score-counts">';
		html += '        <span class="mobilytics-count mobilytics-count--passed">' + counts.passed + ' Passed</span>';
		html += '        <span class="mobilytics-count mobilytics-count--warning">' + counts.warning + ' Warning</span>';
		html += '        <span class="mobilytics-count mobilytics-count--critical">' + counts.critical + ' Critical</span>';
		html += '      </div>';
		html += '      <p class="mobilytics-scanned-url">' + esc( record.url ) + '</p>';
		html += '    </div>';
		html += '  </div>';

		html += '  <div class="mobilytics-category-grid">';
		Object.keys( cats ).forEach( function ( key ) {
			var cat = cats[ key ];
			if ( cat.score === null ) return;
			var ccls = scoreClass( cat.score );
			html += '<div class="mobilytics-category-card">';
			html += '  <h3>' + esc( cat.label ) + '</h3>';
			html += '  <div class="mobilytics-category-score mobilytics-category-score--' + ccls + '">' + cat.score + '</div>';
			html += '  <div class="mobilytics-progress-bar"><div class="mobilytics-progress-fill mobilytics-progress-fill--' + ccls + '" style="width:' + cat.score + '%;"></div></div>';
			html += '  <div class="mobilytics-category-counts">' + cat.passed + '<span class="mobilytics-dot mobilytics-dot--passed"></span>' + cat.warning + '<span class="mobilytics-dot mobilytics-dot--warning"></span>' + cat.critical + '<span class="mobilytics-dot mobilytics-dot--critical"></span></div>';
			html += '</div>';
		} );
		html += '  </div>';
		html += '</div>';

		html += '<div class="mobilytics-detail-section">';
		html += '  <h2>Detailed Audit</h2>';
		html += '  <div class="mobilytics-filter-bar">';
		[ 'all', 'critical', 'warning', 'passed' ].forEach( function ( f, i ) {
			html += '<button type="button" class="mobilytics-filter' + ( i === 0 ? ' active' : '' ) + '" data-filter="' + f + '">' + f.charAt( 0 ).toUpperCase() + f.slice( 1 ) + '</button>';
		} );
		html += '  </div>';

		Object.keys( cats ).forEach( function ( key ) {
			var cat = cats[ key ];
			if ( ! cat.checks || ! cat.checks.length ) return;
			html += '<div class="mobilytics-category-group"><h3>' + esc( cat.label ) + '</h3>';
			cat.checks.forEach( function ( check ) {
				html += '<details class="mobilytics-issue-row mobilytics-issue-row--' + check.status + '" data-status="' + check.status + '">';
				html += '  <summary><span class="mobilytics-badge mobilytics-badge--' + check.status + '">' + check.status.charAt( 0 ).toUpperCase() + check.status.slice( 1 ) + '</span> <strong>' + esc( check.label ) + '</strong> <span class="mobilytics-issue-message">' + esc( check.message ) + '</span></summary>';
				html += '  <div class="mobilytics-issue-body">';
				if ( check.why ) html += '<p><strong>Why it matters:</strong> ' + esc( check.why ) + '</p>';
				if ( check.fix ) html += '<p><strong>How to fix it:</strong> ' + esc( check.fix ) + '</p>';
				html += '  </div>';
				html += '</details>';
			} );
			html += '</div>';
		} );
		html += '</div>';

		resultsRoot.innerHTML = html;
		bindFilters();
	}

	function bindFilters() {
		var buttons = resultsRoot.querySelectorAll( '.mobilytics-filter' );
		var rows = resultsRoot.querySelectorAll( '.mobilytics-issue-row' );
		buttons.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				buttons.forEach( function ( b ) { b.classList.remove( 'active' ); } );
				btn.classList.add( 'active' );
				var filter = btn.getAttribute( 'data-filter' );
				rows.forEach( function ( row ) {
					row.style.display = ( filter === 'all' || row.getAttribute( 'data-status' ) === filter ) ? '' : 'none';
				} );
			} );
		} );
	}

	if ( runBtn ) {
		runBtn.addEventListener( 'click', runFullAudit );
	}
	bindFilters();
} )();
