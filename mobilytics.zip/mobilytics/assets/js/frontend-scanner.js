/**
 * Mobilytics Frontend Scanner
 *
 * Injected into the live front-end page ONLY when a valid, single-use scan
 * token is present (see class-mobilytics-frontend-scanner.php). Runs a set
 * of geometry/layout checks that require an actual rendered DOM (things
 * PHP alone cannot see), then posts the results back to the opening admin
 * window via window.postMessage.
 */
( function () {
	'use strict';

	if ( typeof window.MobilyticsConfig === 'undefined' ) {
		return;
	}

	var cfg = window.MobilyticsConfig; // { token, minFont, minTarget, minSpacing }

	function status( pass, warnLimit, value, higherIsBad ) {
		if ( pass ) return 'passed';
		return 'warning';
	}

	function collect() {
		var results = [];
		var docEl = document.documentElement;
		var viewportWidth = window.innerWidth;

		// ---- 1. Horizontal overflow ----
		var scrollWidth = Math.max( docEl.scrollWidth, document.body ? document.body.scrollWidth : 0 );
		var overflowAmount = scrollWidth - viewportWidth;
		if ( overflowAmount > 5 ) {
			results.push( check(
				'horizontal_overflow', 'Horizontal Scrolling', 'responsive',
				overflowAmount > 40 ? 'critical' : 'warning',
				'Page content is ' + Math.round( overflowAmount ) + 'px wider than the mobile viewport, causing horizontal scroll.',
				'Horizontal scrolling is one of the most disorienting mobile UX problems — visitors have to scroll sideways to read content, and it often signals a layout bug.',
				'Inspect elements with fixed widths, unconstrained tables/images, or negative margins. Add "overflow-x: hidden" only as a last resort — fix the actual oversized element first.'
			) );
		} else {
			results.push( check(
				'horizontal_overflow', 'Horizontal Scrolling', 'responsive', 'passed',
				'No horizontal overflow detected at mobile width.',
				'Content should always fit within the viewport width on mobile.',
				''
			) );
		}

		// ---- 2. Touch target sizing ----
		var interactive = document.querySelectorAll( 'a, button, input[type=button], input[type=submit], input[type=reset], [role="button"]' );
		var minTarget = cfg.minTarget || 44;
		var tooSmall = 0;
		var visibleCount = 0;
		interactive.forEach( function ( el ) {
			var rect = el.getBoundingClientRect();
			if ( rect.width === 0 && rect.height === 0 ) return; // hidden
			visibleCount++;
			if ( rect.width < minTarget || rect.height < minTarget ) {
				tooSmall++;
			}
		} );
		if ( visibleCount > 0 ) {
			var ratio = tooSmall / visibleCount;
			if ( ratio < 0.1 ) {
				results.push( check(
					'touch_target_size', 'Touch Target Size', 'touch_targets', 'passed',
					'Most tappable elements (' + ( visibleCount - tooSmall ) + ' of ' + visibleCount + ') meet the ' + minTarget + 'x' + minTarget + 'px minimum.',
					'Small tap targets cause mis-taps, especially for users with larger fingers or motor impairments.',
					''
				) );
			} else {
				results.push( check(
					'touch_target_size', 'Touch Target Size', 'touch_targets', ratio > 0.3 ? 'critical' : 'warning',
					tooSmall + ' of ' + visibleCount + ' tappable elements are smaller than the recommended ' + minTarget + 'x' + minTarget + 'px minimum.',
					'Apple and Google both recommend at least 44x44px (44x48dp) tap targets. Smaller targets are frustrating and error-prone on touchscreens.',
					'Increase padding on buttons/links, or set a min-width/min-height of ' + minTarget + 'px on tappable elements.'
				) );
			}
		}

		// ---- 3. Spacing between adjacent tap targets ----
		var minSpacing = cfg.minSpacing || 8;
		var crowded = 0;
		var pairsChecked = 0;
		var interactiveArr = Array.prototype.slice.call( interactive ).filter( function ( el ) {
			var r = el.getBoundingClientRect();
			return r.width > 0 && r.height > 0;
		} ).slice( 0, 300 ); // cap for performance

		for ( var i = 0; i < interactiveArr.length; i++ ) {
			var a = interactiveArr[ i ].getBoundingClientRect();
			for ( var j = i + 1; j < interactiveArr.length; j++ ) {
				var b = interactiveArr[ j ].getBoundingClientRect();
				// Only compare elements roughly on the same row (likely neighbors) to keep this cheap & relevant.
				var verticallyClose = Math.abs( a.top - b.top ) < Math.max( a.height, b.height );
				if ( ! verticallyClose ) continue;
				var gap = b.left - a.right;
				if ( gap >= 0 && gap < 200 ) { // plausible neighbors only
					pairsChecked++;
					if ( gap < minSpacing ) {
						crowded++;
					}
				}
			}
		}

		if ( pairsChecked > 0 ) {
			if ( crowded === 0 ) {
				results.push( check(
					'touch_target_spacing', 'Touch Target Spacing', 'touch_targets', 'passed',
					'Neighboring tappable elements have adequate spacing.',
					'Crowded tap targets cause accidental taps on the wrong link or button.',
					''
				) );
			} else {
				results.push( check(
					'touch_target_spacing', 'Touch Target Spacing', 'touch_targets', crowded > 5 ? 'critical' : 'warning',
					crowded + ' pair(s) of neighboring tappable elements are closer than ' + minSpacing + 'px apart.',
					'Insufficient spacing between buttons/links leads to accidental taps, especially on smaller phones.',
					'Add margin/padding of at least ' + minSpacing + 'px between adjacent buttons and links.'
				) );
			}
		}

		// ---- 4. Font sizes (rendered/computed) ----
		var minFont = cfg.minFont || 12;
		var textNodesChecked = 0;
		var textTooSmall = 0;
		var walker = document.createTreeWalker( document.body, NodeFilter.SHOW_ELEMENT, null, false );
		var node;
		var sampleLimit = 400;
		while ( ( node = walker.nextNode() ) && textNodesChecked < sampleLimit ) {
			if ( ! node.textContent || ! node.textContent.trim() ) continue;
			// Only count elements whose direct text (not descendants) is non-empty, to avoid double counting containers.
			var hasDirectText = Array.prototype.some.call( node.childNodes, function ( n ) {
				return n.nodeType === 3 && n.textContent.trim().length > 0;
			} );
			if ( ! hasDirectText ) continue;
			var fs = parseFloat( window.getComputedStyle( node ).fontSize );
			if ( isNaN( fs ) ) continue;
			textNodesChecked++;
			if ( fs < minFont ) textTooSmall++;
		}
		if ( textNodesChecked > 0 ) {
			var fontRatio = textTooSmall / textNodesChecked;
			if ( fontRatio < 0.1 ) {
				results.push( check(
					'rendered_font_size', 'Rendered Text Size', 'readability', 'passed',
					'Sampled ' + textNodesChecked + ' text element(s); nearly all render at ' + minFont + 'px or larger.',
					'Text below ' + minFont + 'px is difficult to read on mobile screens without zooming.',
					''
				) );
			} else {
				results.push( check(
					'rendered_font_size', 'Rendered Text Size', 'readability', fontRatio > 0.3 ? 'critical' : 'warning',
					textTooSmall + ' of ' + textNodesChecked + ' sampled text elements render smaller than ' + minFont + 'px.',
					'Small rendered text is a top mobile usability complaint and forces pinch-zooming to read.',
					'Set a base font-size of at least 16px on body text, and audit custom classes/widgets overriding it smaller.'
				) );
			}
		}

		// ---- 5. Fixed-width elements exceeding viewport (computed, not just inline) ----
		var allEls = document.body.querySelectorAll( '*' );
		var overflowingFixed = 0;
		var sampled = 0;
		for ( var k = 0; k < allEls.length && sampled < 800; k++ ) {
			var el2 = allEls[ k ];
			var cs = window.getComputedStyle( el2 );
			if ( cs.position === 'fixed' || cs.display === 'none' ) continue;
			sampled++;
			var rect2 = el2.getBoundingClientRect();
			if ( rect2.width > viewportWidth + 10 && rect2.width > 50 ) {
				overflowingFixed++;
			}
		}
		if ( overflowingFixed > 0 ) {
			results.push( check(
				'computed_fixed_width', 'Elements Wider Than Screen', 'responsive', overflowingFixed > 5 ? 'critical' : 'warning',
				overflowingFixed + ' rendered element(s) are wider than the mobile viewport (' + viewportWidth + 'px).',
				'Elements that render wider than the screen are the direct cause of horizontal scrolling and broken layouts.',
				'Use browser DevTools mobile emulation to find these elements and apply max-width: 100% or switch fixed widths to relative units.'
			) );
		} else if ( sampled > 0 ) {
			results.push( check(
				'computed_fixed_width', 'Elements Wider Than Screen', 'responsive', 'passed',
				'No rendered elements exceed the mobile viewport width.',
				'All content fits comfortably within the screen at mobile width.',
				''
			) );
		}

		// ---- 6. Input sizing (forms) ----
		var inputs = document.querySelectorAll( 'input:not([type=hidden]), textarea, select' );
		var smallInputs = 0;
		var zoomTriggerInputs = 0;
		inputs.forEach( function ( inp ) {
			var r = inp.getBoundingClientRect();
			if ( r.width === 0 && r.height === 0 ) return;
			if ( r.height < 40 ) smallInputs++;
			var fs = parseFloat( window.getComputedStyle( inp ).fontSize );
			if ( ! isNaN( fs ) && fs < 16 ) zoomTriggerInputs++; // iOS Safari auto-zooms on inputs under 16px
		} );
		if ( inputs.length > 0 ) {
			if ( smallInputs === 0 && zoomTriggerInputs === 0 ) {
				results.push( check(
					'input_sizing', 'Form Input Sizing', 'touch_targets', 'passed',
					'Form fields are comfortably sized and use a 16px+ font size.',
					'Well-sized inputs are easy to tap accurately, and 16px+ font avoids unwanted auto-zoom on iOS.',
					''
				) );
			} else {
				results.push( check(
					'input_sizing', 'Form Input Sizing', 'touch_targets', ( smallInputs + zoomTriggerInputs ) > 4 ? 'critical' : 'warning',
					smallInputs + ' input(s) are shorter than 40px tall, and ' + zoomTriggerInputs + ' use a font under 16px (triggers auto-zoom on iOS Safari).',
					'Small inputs are hard to tap accurately, and sub-16px input text causes iOS Safari to zoom in automatically when a field is focused, disorienting users.',
					'Set form inputs to at least 44px tall with 16px+ font size.'
				) );
			}
		}

		// ---- 7. Intrusive popups actually visible on load ----
		var overlays = document.querySelectorAll( '[class*="popup" i], [class*="modal" i], [class*="overlay" i], [class*="lightbox" i]' );
		var intrusive = 0;
		overlays.forEach( function ( el ) {
			var cs = window.getComputedStyle( el );
			if ( cs.display === 'none' || cs.visibility === 'hidden' || parseFloat( cs.opacity ) === 0 ) return;
			var rect = el.getBoundingClientRect();
			var coverage = ( rect.width * rect.height ) / ( viewportWidth * window.innerHeight );
			if ( ( cs.position === 'fixed' || cs.position === 'absolute' ) && coverage > 0.4 ) {
				intrusive++;
			}
		} );
		if ( intrusive > 0 ) {
			results.push( check(
				'intrusive_popup_visible', 'Intrusive Popup On Load', 'accessibility', 'critical',
				intrusive + ' large overlay/popup element(s) are visible immediately and cover a significant part of the screen.',
				"Interstitials that cover the majority of the screen immediately on load are explicitly flagged by Google's mobile-friendly guidelines and frustrate visitors trying to read your content.",
				'Delay the popup, shrink it, or replace it with a small banner. Always include a large, easy-to-tap close button.'
			) );
		} else {
			results.push( check(
				'intrusive_popup_visible', 'Intrusive Popup On Load', 'accessibility', 'passed',
				'No large intrusive overlay is visible immediately on page load.',
				'Content should be immediately readable without dismissing a popup first.',
				''
			) );
		}

		// ---- 8. Excessive DOM elements (rendered) ----
		var totalEls = document.querySelectorAll( '*' ).length;
		var limit = cfg.maxElements || 1500;
		if ( totalEls > limit ) {
			results.push( check(
				'rendered_dom_size', 'Rendered Page Complexity', 'performance', totalEls > limit * 1.5 ? 'critical' : 'warning',
				'Rendered page contains ' + totalEls + ' DOM elements (threshold: ' + limit + ').',
				'Very large DOM trees slow scrolling and interaction responsiveness on mobile devices, especially older/lower-powered phones.',
				'Simplify nested page-builder markup and lazy-load below-the-fold sections.'
			) );
		} else {
			results.push( check(
				'rendered_dom_size', 'Rendered Page Complexity', 'performance', 'passed',
				'Rendered page contains ' + totalEls + ' DOM elements, within a healthy range.',
				'A leaner DOM renders and scrolls more smoothly on mobile devices.',
				''
			) );
		}

		return results;
	}

	function check( id, label, category, statusVal, message, why, fix ) {
		return { id: id, label: label, category: category, status: statusVal, message: message, why: why, fix: fix, weight: 2, source: 'client' };
	}

	function run() {
		var results;
		try {
			results = collect();
		} catch ( e ) {
			results = [];
		}
		var payload = { mobilytics: true, token: cfg.token, results: results };
		if ( window.parent ) {
			window.parent.postMessage( payload, '*' );
		}
	}

	if ( document.readyState === 'complete' ) {
		setTimeout( run, 400 ); // let layout settle
	} else {
		window.addEventListener( 'load', function () {
			setTimeout( run, 400 );
		} );
	}
} )();
