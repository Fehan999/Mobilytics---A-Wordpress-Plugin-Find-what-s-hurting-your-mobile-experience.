( function () {
	'use strict';

	function escapeHtml( str ) {
		var div = document.createElement( 'div' );
		div.textContent = str == null ? '' : String( str );
		return div.innerHTML;
	}

	function statusBadge( status ) {
		var map = { passed: 'Passed', warning: 'Warning', critical: 'Critical' };
		var label = map[ status ] || status;
		return '<span class="mobilytics-badge mobilytics-badge--' + status + '">' + label + '</span>';
	}

	function scoreClass( score ) {
		if ( score >= 80 ) return 'good';
		if ( score >= 50 ) return 'warning';
		return 'critical';
	}

	function render( data ) {
		var el = document.getElementById( 'mobilytics-public-report' );
		if ( ! el ) return;

		var score = data.score.overall_score;
		var grade = data.score.grade;

		var html = '';

		html += '<div class="mobilytics-report-toolbar no-print">';
		html += '  <button type="button" id="mobilytics-download-pdf" class="mobilytics-btn mobilytics-btn--primary">' + 'Download PDF' + '</button>';
		html += '</div>';

		html += '<header class="mobilytics-report-header">';
		if ( data.branding.agency_logo_url ) {
			html += '<img class="mobilytics-report-logo" src="' + escapeHtml( data.branding.agency_logo_url ) + '" alt="' + escapeHtml( data.branding.agency_name ) + '" />';
		}
		html += '  <h1>Mobile UX Report</h1>';
		html += '  <p class="mobilytics-report-url">' + escapeHtml( data.url ) + '</p>';
		html += '  <p class="mobilytics-report-date">Scanned ' + escapeHtml( data.timestamp ) + '</p>';
		html += '</header>';

		html += '<section class="mobilytics-score-hero mobilytics-score-hero--' + scoreClass( score ) + '">';
		html += '  <div class="mobilytics-score-circle"><span>' + score + '</span><small>/100</small></div>';
		html += '  <div class="mobilytics-score-label">' + escapeHtml( grade.label ) + '</div>';
		html += '</section>';

		html += '<section class="mobilytics-category-grid">';
		Object.keys( data.score.categories ).forEach( function ( key ) {
			var cat = data.score.categories[ key ];
			if ( null === cat.score ) return;
			html += '<div class="mobilytics-category-card">';
			html += '  <h3>' + escapeHtml( cat.label ) + '</h3>';
			html += '  <div class="mobilytics-category-score ' + scoreClass( cat.score ) + '">' + cat.score + '</div>';
			html += '  <div class="mobilytics-category-counts">';
			html += '    <span class="mobilytics-count mobilytics-count--passed">' + cat.passed + ' passed</span>';
			html += '    <span class="mobilytics-count mobilytics-count--warning">' + cat.warning + ' warning</span>';
			html += '    <span class="mobilytics-count mobilytics-count--critical">' + cat.critical + ' critical</span>';
			html += '  </div>';
			html += '</div>';
		} );
		html += '</section>';

		var issues = data.checks.filter( function ( c ) { return c.status !== 'passed'; } );
		var passed = data.checks.filter( function ( c ) { return c.status === 'passed'; } );

		if ( issues.length ) {
			html += '<section class="mobilytics-report-section"><h2>Issues Found (' + issues.length + ')</h2>';
			issues.sort( function ( a, b ) {
				var order = { critical: 0, warning: 1 };
				return ( order[ a.status ] || 2 ) - ( order[ b.status ] || 2 );
			} );
			issues.forEach( function ( c ) {
				html += '<details class="mobilytics-issue mobilytics-issue--' + c.status + '">';
				html += '  <summary>' + statusBadge( c.status ) + ' <strong>' + escapeHtml( c.label ) + '</strong></summary>';
				html += '  <p class="mobilytics-issue-message">' + escapeHtml( c.message ) + '</p>';
				if ( c.why ) html += '  <p class="mobilytics-issue-why"><strong>Why it matters:</strong> ' + escapeHtml( c.why ) + '</p>';
				if ( c.fix ) html += '  <p class="mobilytics-issue-fix"><strong>How to fix it:</strong> ' + escapeHtml( c.fix ) + '</p>';
				html += '</details>';
			} );
			html += '</section>';
		}

		if ( passed.length ) {
			html += '<section class="mobilytics-report-section"><h2>Passed Checks (' + passed.length + ')</h2><ul class="mobilytics-passed-list">';
			passed.forEach( function ( c ) {
				html += '<li>' + statusBadge( c.status ) + ' ' + escapeHtml( c.label ) + '</li>';
			} );
			html += '</ul></section>';
		}

		if ( data.cta ) {
			html += '<section class="mobilytics-cta">';
			html += '  <h2>' + escapeHtml( data.cta.heading ) + '</h2>';
			html += '  <p>' + escapeHtml( data.cta.text ) + '</p>';
			if ( data.cta.contact_url ) {
				html += '  <a class="mobilytics-btn mobilytics-btn--primary" href="' + escapeHtml( data.cta.contact_url ) + '">' + escapeHtml( data.cta.button_label ) + '</a>';
			}
			html += '</section>';
		}

		el.innerHTML = html;

		var pdfBtn = document.getElementById( 'mobilytics-download-pdf' );
		if ( pdfBtn ) {
			pdfBtn.addEventListener( 'click', function () {
				window.print();
			} );
		}
	}

	function init() {
		if ( typeof MobilyticsReport === 'undefined' ) return;
		fetch( MobilyticsReport.restUrl )
			.then( function ( r ) {
				if ( ! r.ok ) throw new Error( 'not ok' );
				return r.json();
			} )
			.then( render )
			.catch( function () {
				var el = document.getElementById( 'mobilytics-public-report' );
				if ( el ) el.innerHTML = '<p>No audit report is available yet.</p>';
			} );
	}

	document.addEventListener( 'DOMContentLoaded', init );
} )();
