<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Report
 *
 * Renders the public, client-friendly "Mobile UX Report" via a shortcode:
 *   [mobilytics_report]
 * Drop this shortcode on any page (e.g. /mobile-ux-report/) to give
 * clients a clean, brandable summary they can view or print/export as PDF
 * (via the browser's native print-to-PDF, triggered by a "Download PDF"
 * button and a dedicated print stylesheet — no extra PHP library needed).
 */
class Mobilytics_Report {

	public function __construct() {
		add_shortcode( 'mobilytics_report', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_assets' ) );
	}

	public function maybe_enqueue_assets() {
		global $post;
		if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'mobilytics_report' ) ) {
			return;
		}
		wp_enqueue_style( 'mobilytics-report', MOBILYTICS_URL . 'assets/css/report.css', array(), MOBILYTICS_VERSION );
		wp_enqueue_script( 'mobilytics-report', MOBILYTICS_URL . 'assets/js/report.js', array(), MOBILYTICS_VERSION, true );
		wp_localize_script( 'mobilytics-report', 'MobilyticsReport', array(
			'restUrl' => esc_url_raw( rest_url( 'mobilytics/v1/report' ) ),
		) );
	}

	public function render_shortcode( $atts ) {
		ob_start();
		?>
		<div id="mobilytics-public-report" class="mobilytics-report" aria-live="polite">
			<p class="mobilytics-report-loading"><?php esc_html_e( 'Loading mobile UX report…', 'mobilytics' ); ?></p>
		</div>
		<?php
		return ob_get_clean();
	}
}
