<?php
/**
 * Plugin Name:       Mobilytics — WordPress Mobile UX Auditor
 * Plugin URI:        https://github.com/Fehan999/Mobilytics---A-Wordpress-Plugin-Find-what-s-hurting-your-mobile-experience.
 * Description:       Find what's hurting your mobile experience. Mobilytics audits your site's mobile UX (responsive design, readability, touch targets, navigation, images, performance, accessibility, mobile SEO) and gives you a clear score, prioritized issues, and plain-English fixes.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ehan Siddique
 * Author URI:        https://www.linkedin.com/in/ehan-siddique-0742aa34b/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mobilytics
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------
define( 'MOBILYTICS_VERSION', '1.0.0' );
define( 'MOBILYTICS_FILE', __FILE__ );
define( 'MOBILYTICS_PATH', plugin_dir_path( __FILE__ ) );
define( 'MOBILYTICS_URL', plugin_dir_url( __FILE__ ) );
define( 'MOBILYTICS_BASENAME', plugin_basename( __FILE__ ) );
define( 'MOBILYTICS_OPTION_RESULTS', 'mobilytics_last_results' );
define( 'MOBILYTICS_OPTION_SETTINGS', 'mobilytics_settings' );
define( 'MOBILYTICS_OPTION_HISTORY', 'mobilytics_history' );
define( 'MOBILYTICS_CAPABILITY', 'manage_options' );

// ---------------------------------------------------------------------
// Includes — order matters: dependencies must load first.
// ---------------------------------------------------------------------
$mobilytics_includes = array(
	'includes/class-mobilytics-settings.php',
	'includes/class-mobilytics-scorer.php',
	'includes/class-mobilytics-checks.php',
	'includes/class-mobilytics-frontend-scanner.php',
	'includes/class-mobilytics-audit-engine.php',
	'includes/class-mobilytics-ajax.php',
	'includes/class-mobilytics-rest.php',
	'reports/class-mobilytics-report.php',
	'admin/class-mobilytics-admin.php',
);

foreach ( $mobilytics_includes as $mobilytics_include ) {
	$mobilytics_file = MOBILYTICS_PATH . $mobilytics_include;
	if ( file_exists( $mobilytics_file ) ) {
		require_once $mobilytics_file;
	}
}
unset( $mobilytics_includes, $mobilytics_include, $mobilytics_file );

/**
 * Core plugin bootstrap / singleton.
 */
final class Mobilytics {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( MOBILYTICS_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( MOBILYTICS_FILE, array( $this, 'deactivate' ) );

		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_filter( 'cron_schedules', array( $this, 'add_monthly_schedule' ) );
	}

	public function add_monthly_schedule( $schedules ) {
		if ( ! isset( $schedules['monthly'] ) ) {
			$schedules['monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'mobilytics' ),
			);
		}
		return $schedules;
	}

	public function init() {
		load_plugin_textdomain( 'mobilytics', false, dirname( MOBILYTICS_BASENAME ) . '/languages' );

		if ( class_exists( 'Mobilytics_Admin' ) ) {
			new Mobilytics_Admin();
		}
		if ( class_exists( 'Mobilytics_Ajax' ) ) {
			new Mobilytics_Ajax();
		}
		if ( class_exists( 'Mobilytics_REST' ) ) {
			new Mobilytics_REST();
		}
		if ( class_exists( 'Mobilytics_Frontend_Scanner' ) ) {
			new Mobilytics_Frontend_Scanner();
		}
		if ( class_exists( 'Mobilytics_Report' ) ) {
			new Mobilytics_Report();
		}

		add_action( 'mobilytics_scheduled_scan', array( 'Mobilytics_Audit_Engine', 'run_scheduled' ) );
		$this->maybe_reschedule();
	}

	public function activate() {
		if ( class_exists( 'Mobilytics_Settings' ) ) {
			$defaults = Mobilytics_Settings::defaults();
			if ( false === get_option( MOBILYTICS_OPTION_SETTINGS ) ) {
				add_option( MOBILYTICS_OPTION_SETTINGS, $defaults );
			}
		}
		if ( false === get_option( MOBILYTICS_OPTION_HISTORY ) ) {
			add_option( MOBILYTICS_OPTION_HISTORY, array() );
		}
	}

	public function deactivate() {
		$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'mobilytics_scheduled_scan' );
			$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
		}
	}

	private function maybe_reschedule() {
		$settings  = Mobilytics_Settings::get();
		$frequency = isset( $settings['scan_frequency'] ) ? $settings['scan_frequency'] : 'manual';

		$scheduled = wp_next_scheduled( 'mobilytics_scheduled_scan' );

		if ( 'manual' === $frequency ) {
			while ( $scheduled ) {
				wp_unschedule_event( $scheduled, 'mobilytics_scheduled_scan' );
				$scheduled = wp_next_scheduled( 'mobilytics_scheduled_scan' );
			}
			return;
		}

		$map = array(
			'daily'   => 'daily',
			'weekly'  => 'weekly',
			'monthly' => 'monthly',
		);

		$recurrence = isset( $map[ $frequency ] ) ? $map[ $frequency ] : false;
		if ( ! $recurrence ) {
			return;
		}

		if ( ! $scheduled ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $recurrence, 'mobilytics_scheduled_scan' );
		}
	}
}

Mobilytics::instance();