<?php
/**
 * Plugin Name:       Mobilytics — WordPress Mobile UX Auditor
 * Plugin URI:        https://github.com/yourname/mobilytics
 * Description:       Find what's hurting your mobile experience. Mobilytics audits your site's mobile UX (responsive design, readability, touch targets, navigation, images, performance, accessibility, mobile SEO) and gives you a clear score, prioritized issues, and plain-English fixes.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://yourwebsite.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mobilytics
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

// ---------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------
define( 'MOBILYTICS_VERSION', '1.0.0' );
define( 'MOBILYTICS_FILE', __FILE__ );
define( 'MOBILYTICS_PATH', plugin_dir_path( __FILE__ ) );
define( 'MOBILYTICS_URL', plugin_dir_url( __FILE__ ) );
define( 'MOBILYTICS_BASENAME', plugin_basename( __FILE__ ) );
define( 'MOBILYTICS_OPTION_RESULTS', 'mobilytics_last_results' );
define( 'MOBILYTICS_OPTION_SETTINGS', 'mobilytics_settings' );
define( 'MOBILYTICS_OPTION_HISTORY', 'mobilytics_history' );
define( 'MOBILYTICS_CAPABILITY', 'manage_options' );

// ---------------------------------------------------------------------
// Includes
// ---------------------------------------------------------------------
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-settings.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-checks.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-scorer.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-audit-engine.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-ajax.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-frontend-scanner.php';
require_once MOBILYTICS_PATH . 'includes/class-mobilytics-rest.php';
require_once MOBILYTICS_PATH . 'reports/class-mobilytics-report.php';
require_once MOBILYTICS_PATH . 'admin/class-mobilytics-admin.php';

/**
 * Core plugin bootstrap / singleton.
 */
final class Mobilytics {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( MOBILYTICS_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( MOBILYTICS_FILE, array( $this, 'deactivate' ) );

		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_filter( 'cron_schedules', array( $this, 'add_monthly_schedule' ) );
	}

	/**
	 * WordPress has no built-in "monthly" cron recurrence — add one.
	 */
	public function add_monthly_schedule( $schedules ) {
		if ( ! isset( $schedules['monthly'] ) ) {
			$schedules['monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once Monthly', 'mobilytics' ),
			);
		}
		return $schedules;
	}

	public function init() {
		load_plugin_textdomain( 'mobilytics', false, dirname( MOBILYTICS_BASENAME ) . '/languages' );

		// Admin UI (menus, assets, settings page, dashboard page).
		new Mobilytics_Admin();

		// AJAX endpoints (run audit, save results).
		new Mobilytics_Ajax();

		// REST endpoints (public shareable report).
		new Mobilytics_REST();

		// Frontend scanner injection (used only during an active scan token).
		new Mobilytics_Frontend_Scanner();

		// Scheduled scans, based on settings (daily/weekly/monthly).
		add_action( 'mobilytics_scheduled_scan', array( 'Mobilytics_Audit_Engine', 'run_scheduled' ) );
		$this->maybe_reschedule();
	}

	public function activate() {
		$defaults = Mobilytics_Settings::defaults();
		if ( false === get_option( MOBILYTICS_OPTION_SETTINGS ) ) {
			add_option( MOBILYTICS_OPTION_SETTINGS, $defaults );
		}
		if ( false === get_option( MOBILYTICS_OPTION_HISTORY ) ) {
			add_option( MOBILYTICS_OPTION_HISTORY, array() );
		}
	}

	public function deactivate() {
		$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'mobilytics_scheduled_scan' );
		}
	}

	/**
	 * Keep the cron schedule in sync with the configured scan frequency.
	 */
	private function maybe_reschedule() {
		$settings = Mobilytics_Settings::get();
		$frequency = isset( $settings['scan_frequency'] ) ? $settings['scan_frequency'] : 'manual';

		$scheduled = wp_next_scheduled( 'mobilytics_scheduled_scan' );

		if ( 'manual' === $frequency ) {
			if ( $scheduled ) {
				wp_unschedule_event( $scheduled, 'mobilytics_scheduled_scan' );
			}
			return;
		}

		$map = array(
			'daily'   => 'daily',
			'weekly'  => 'weekly',
			'monthly' => 'monthly',
		);

		$recurrence = isset( $map[ $frequency ] ) ? $map[ $frequency ] : false;

		if ( ! $recurrence ) {
			return;
		}

		if ( ! $scheduled ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $recurrence, 'mobilytics_scheduled_scan' );
		}
	}
}

Mobilytics::instance();
