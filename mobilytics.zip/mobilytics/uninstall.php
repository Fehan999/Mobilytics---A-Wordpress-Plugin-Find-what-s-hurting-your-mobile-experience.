<?php
/**
 * Mobilytics — Uninstall
 *
 * Removes plugin options, transients, and scheduled events when deleted.
 *
 * @package Mobilytics
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up a single site's Mobilytics data.
 */
function mobilytics_uninstall_site() {
	// -----------------------------------------------------------------
	// Options
	// -----------------------------------------------------------------
	$options = array(
		'mobilytics_settings',
		'mobilytics_last_results',
		'mobilytics_history',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
		delete_site_option( $option );
	}

	// -----------------------------------------------------------------
	// Transients (scan tokens + cached data)
	// -----------------------------------------------------------------
	global $wpdb;

	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE %s
			    OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_mobilytics_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_mobilytics_' ) . '%'
		)
	);

	if ( is_multisite() ) {
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->sitemeta}
				 WHERE meta_key LIKE %s
				    OR meta_key LIKE %s",
				$wpdb->esc_like( '_site_transient_mobilytics_' ) . '%',
				$wpdb->esc_like( '_site_transient_timeout_mobilytics_' ) . '%'
			)
		);
	}

	// -----------------------------------------------------------------
	// Scheduled events — loop in case of duplicates.
	// -----------------------------------------------------------------
	$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
	while ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'mobilytics_scheduled_scan' );
		$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
	}
}

// ---------------------------------------------------------------------
// Run for single site or every site in a multisite network.
// ---------------------------------------------------------------------
if ( is_multisite() ) {
	$mobilytics_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $mobilytics_site_ids as $mobilytics_site_id ) {
		switch_to_blog( $mobilytics_site_id );
		mobilytics_uninstall_site();
		restore_current_blog();
	}
} else {
	mobilytics_uninstall_site();
}