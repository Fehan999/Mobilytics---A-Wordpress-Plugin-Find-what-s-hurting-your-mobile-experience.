<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'mobilytics_settings' );
delete_option( 'mobilytics_last_results' );
delete_option( 'mobilytics_history' );

$timestamp = wp_next_scheduled( 'mobilytics_scheduled_scan' );
if ( $timestamp ) {
	wp_unschedule_event( $timestamp, 'mobilytics_scheduled_scan' );
}
