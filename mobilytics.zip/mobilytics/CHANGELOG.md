# Changelog

## 1.0.0
- Initial release.
- Admin dashboard with Overall Mobile UX Score, 8 category scores, and a detailed expandable audit list.
- 24 checks across Responsive Design, Readability, Touch Targets, Navigation, Images, Performance, Accessibility, and Mobile SEO.
- Two-phase scan engine: server-side DOMDocument checks + client-side geometry checks via a token-gated hidden iframe.
- "Run Mobile Audit" button with loading state and last-scan timestamp.
- Public `[mobilytics_report]` shortcode with a branded, client-friendly report and PDF export (browser print).
- Configurable lead-gen CTA block.
- Settings page: scan frequency, excluded pages, score thresholds, minimum touch target/spacing/font size, branding, report options.
- REST endpoint for the public report; AJAX endpoints for running scans, both properly secured.
