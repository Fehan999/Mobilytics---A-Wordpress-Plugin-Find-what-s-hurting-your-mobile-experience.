# Mobilytics — WordPress Mobile UX Auditor

**Find what's hurting your mobile experience.**

Mobilytics is a lightweight WordPress plugin that audits any WordPress site's mobile user experience and turns it into something a site owner (or their web developer) can actually act on: a single **0–100 Mobile UX Score**, eight category scores, ~20 individual checks each marked Passed/Warning/Critical, and a plain-English explanation of *why it matters* and *how to fix it* — plus a client-friendly report you can hand to a customer as a lead-generation tool.

> This project was built as a portfolio piece to demonstrate end-to-end WordPress product development: plugin architecture, PHP + JavaScript engineering, UX/performance analysis, and client-facing product thinking — not just a script, but something shaped like a real, shippable tool.

---

## Table of Contents

- [Why This Exists](#why-this-exists)
- [Feature List](#feature-list)
- [Screenshots](#screenshots)
- [Demo Video](#demo-video)
- [Installation](#installation)
- [Usage](#usage)
- [The 20 Checks](#the-20-checks)
- [Technical Documentation](#technical-documentation)
- [Architecture Decisions](#architecture-decisions--why-v1-is-scoped-this-way)
- [Roadmap (V2+)](#roadmap-v2)
- [Portfolio Case Study](#portfolio-case-study)
- [License](#license)

---

## Why This Exists

Most site owners know mobile matters, but "run a Lighthouse audit" is not something they can act on — the reports are built for engineers. Mobilytics is built for the other 90%: it lives inside the WordPress dashboard they already use, speaks in plain language, and turns every finding into a task ("here's what's wrong, here's why it matters, here's how to fix it").

For a freelance/agency developer, it doubles as a **lead-generation tool**: run it on a prospect's site, hand them the branded client report with a "Need help fixing these issues?" call-to-action, and you've turned an audit into a warm sales conversation.

## Feature List

- **Overall Mobile UX Score (0–100)** with a "Good / Needs Work / Critical" grade
- **8 category scores**: Responsive Design, Readability, Touch Targets, Navigation, Images, Performance, Accessibility, Mobile SEO
- **~20 reliable checks**, each with a Passed / Warning / Critical status, a plain-language explanation of *why it matters*, and a specific *how to fix it* recommendation
- **One-click "Run Mobile Audit"** button with a loading state, progress messaging, and a timestamp of the last scan
- **Beautiful admin dashboard**: score ring, category cards with mini progress bars, severity badges, filterable/expandable issue list
- **Public, brandable "Mobile UX Report"** via a simple `[mobilytics_report]` shortcode — shareable with clients, no login required (optional)
- **PDF export** of the client report via the browser's native print-to-PDF (a dedicated print stylesheet keeps it clean — no heavy PDF library dependency)
- **Lead-gen CTA block** ("Need help fixing these issues?") with configurable heading, copy, button label, and contact URL
- **Settings page**: scan frequency (manual/daily/weekly/monthly via WP-Cron), excluded pages, score thresholds, minimum touch-target size/spacing/font size, branding (name + logo), report options
- **REST API endpoint** (`/wp-json/mobilytics/v1/report`) serving the public report data
- **AJAX endpoints** for running scans from the dashboard, protected by nonces and capability checks
- Built with WordPress best practices: nonces, `current_user_can()` capability checks, `sanitize_*`/`esc_*` throughout, `uninstall.php` cleanup, translation-ready strings

## Screenshots

> Screenshots are best captured from a live install since they depend on your test site's content. Recommended shots for a polished listing:
> 1. Dashboard — empty state ("No audit yet")
> 2. Dashboard — mid-scan loading state
> 3. Dashboard — full results (score ring + 8 category cards)
> 4. Detailed audit accordion, expanded, showing Why/Fix copy
> 5. Settings page
> 6. Public client report (desktop + mobile widths)
> 7. The PDF export output
>
> `/assets/css/admin.css` and `/assets/css/report.css` are written so all of the above render cleanly for screenshots without any manual styling.

## Demo Video

> Suggested 90–120 second walkthrough script:
> 1. (0:00) Show the tagline and the empty dashboard state.
> 2. (0:10) Click **Run Mobile Audit**, narrate the two-phase scan (server checks, then a simulated mobile viewport check) as the loading state plays.
> 3. (0:30) Land on the results: point out the score ring, then hover across the 8 category cards.
> 4. (0:50) Expand 2–3 issues in the Detailed Audit accordion, reading one "Why it matters" / "How to fix it" pair aloud.
> 5. (1:10) Switch to the public report page, show the CTA block, click **Download PDF**.
> 6. (1:35) Open Settings briefly — thresholds, branding, CTA fields.
> 7. (1:50) Close on the tagline card again.
> Record with OBS or QuickTime at 1080p; a phone-width browser resize (DevTools device toolbar) for the report page sells the "mobile" story visually.

## Installation

1. Download or clone this repository into `wp-content/plugins/mobilytics/` (or zip the folder and upload via **Plugins → Add New → Upload Plugin**).
2. Activate **Mobilytics** from the **Plugins** screen.
3. Go to **Mobilytics** in the admin sidebar.
4. Click **Run Mobile Audit**. On first run this scans your site's homepage (configurable in **Mobilytics → Settings**).
5. *(Optional)* Create a page (e.g. `/mobile-ux-report/`) and add the shortcode:
   ```
   [mobilytics_report]
   ```
   to give clients a public, brandable report.
6. *(Optional)* Visit **Mobilytics → Settings** to set your scan frequency, thresholds, branding, and the "Need help fixing these issues?" CTA.

**Requirements:** WordPress 5.8+, PHP 7.4+. No external services or API keys required — everything runs on your own server.

## Usage

- **Run Mobile Audit** — triggers a fresh scan. The button shows a loading state and the dashboard timestamp updates once results are in.
- **Category cards** — each shows a 0–100 score, a mini progress bar, and Passed/Warning/Critical counts.
- **Detailed Audit** — every individual check, grouped by category, expandable for the full explanation. Filter by status (All / Critical / Warning / Passed) with the pill buttons above the list.
- **Public report** — add `[mobilytics_report]` to any page. It pulls the latest scan via REST and renders a client-friendly summary with a **Download PDF** button (browser print-to-PDF).
- **Settings** — configure everything without touching code: scan frequency, excluded pages, thresholds, branding, CTA copy, and whether the public report requires login.

## The 20 Checks

| # | Category | Check | What It Looks At |
|---|----------|-------|-------------------|
| 1 | Responsive Design | Viewport Meta Tag | `<meta name="viewport">` present & correctly configured |
| 2 | Responsive Design | Responsive CSS Detected | Media query / responsive-framework heuristics |
| 3 | Responsive Design | Fixed-Width Elements (inline) | Inline `style="width:###px"` wider than a phone screen |
| 4 | Responsive Design | Elements Wider Than Screen (rendered) | Computed layout width vs. viewport, in a real mobile-width render |
| 5 | Readability | Text Size (inline hint) | Inline `font-size` under the configured minimum |
| 6 | Readability | Readable Text Blocks | Long unbroken text runs that could overflow |
| 7 | Readability | Rendered Text Size | Computed font-size sampled across the rendered page |
| 8 | Touch Targets | Touch Target Size | Buttons/links smaller than the recommended 44×44px |
| 9 | Touch Targets | Touch Target Spacing | Distance between neighboring tappable elements |
| 10 | Touch Targets | Form Input Sizing | Input height + font-size (avoids iOS auto-zoom under 16px) |
| 11 | Navigation | Navigation Menu Size | Top-level menu item count |
| 12 | Navigation | Mobile Menu Pattern | Hamburger/mobile-menu markup detection |
| 13 | Images | Image Dimensions Set | Missing `width`/`height` attributes (CLS risk) |
| 14 | Images | Image Alt Text | Missing/empty `alt` attributes |
| 15 | Images | Image File Sizes | Sampled image weight vs. configured KB threshold |
| 16 | Performance | Render-Blocking Resources | Un-async/deferred `<script>` + stylesheet count in `<head>` |
| 17 | Performance | Page Complexity (DOM Size) | Total DOM element count, server + rendered |
| 18 | Performance | HTML Document Size | Raw HTML payload size |
| 19 | Accessibility | Form Field Labels | Inputs without a `<label>`/`aria-label` |
| 20 | Accessibility | Intrusive Popups | Popup/modal markup + actual on-load visibility/coverage |
| 21 | Accessibility | Text Resize Allowed | `-webkit-text-size-adjust: none` detection |
| 22 | Mobile SEO | Clear Calls-to-Action | Ratio of generic ("click here") vs. descriptive link text |
| 23 | Mobile SEO | Title & Meta Description | Length checks tuned for mobile SERP truncation |
| 24 | Mobile SEO | Language Declared | `<html lang="...">` presence |

*(24 checks shipped — a few above the "15–25" target range because several are cheap, high-signal, and low false-positive; each is independently toggled off automatically when its category has zero applicable elements on the page, e.g. a page with no images skips the two image-weight checks rather than reporting a false failure.)*

## Technical Documentation

### Plugin Structure

```
mobilytics/
├── mobilytics.php                     # Bootstrap: constants, hooks, activation/deactivation, cron
├── uninstall.php                      # Cleans up options + scheduled events on uninstall
├── includes/
│   ├── class-mobilytics-settings.php       # Defaults, get/update, sanitization, exclusion matching
│   ├── class-mobilytics-checks.php         # Server-side (DOMDocument-based) checks
│   ├── class-mobilytics-scorer.php         # Category + overall scoring from check results
│   ├── class-mobilytics-audit-engine.php   # Orchestrates fetch → check → score → persist
│   ├── class-mobilytics-ajax.php           # wp_ajax_* endpoints (nonce + capability guarded)
│   ├── class-mobilytics-frontend-scanner.php # Token-gated injection of the JS scanner on the live front end
│   └── class-mobilytics-rest.php           # Public REST endpoint for the client report
├── admin/
│   ├── class-mobilytics-admin.php          # Menu registration, asset enqueue, page rendering
│   └── views/
│       ├── dashboard-page.php
│       ├── dashboard-results-template.php  # Shared partial (initial PHP render + JS re-render mirror)
│       └── settings-page.php
├── assets/
│   ├── css/
│   │   ├── admin.css                       # Dashboard + settings styling
│   │   └── report.css                      # Public report styling + print/PDF rules
│   └── js/
│       ├── admin.js                        # Run-audit orchestration, rendering, filters
│       ├── frontend-scanner.js             # Geometry checks run inside a hidden mobile-width iframe
│       └── report.js                       # Fetches + renders the public report, wires up PDF export
└── reports/
    └── class-mobilytics-report.php         # [mobilytics_report] shortcode + asset loading
```

### How a Scan Works (Two-Phase Architecture)

A meaningful mobile audit needs two kinds of checks:

1. **Static checks** — things visible in the raw HTML/settings alone (viewport tag, alt text, image weight, render-blocking scripts, meta tags…). These run entirely in PHP against the fetched HTML via `DOMDocument`/`DOMXPath`. No browser needed, so these can also run unattended via WP-Cron for scheduled scans.
2. **Geometry checks** — things that only exist once a browser actually lays the page out (horizontal overflow, computed font size, real tap-target dimensions and spacing, whether a popup visually covers the screen). These require a real rendered DOM, which PHP cannot see.

Mobilytics solves this without requiring a headless-browser service or external API:

```
[Run Mobile Audit clicked]
        │
        ▼
① AJAX: mobilytics_start_scan
   PHP fetches the page HTML (wp_remote_get) and runs
   Mobilytics_Checks::run_all() (DOMDocument-based).
   Returns: server check results + a single-use scan token
   + an iframe URL pointing at the live front end with that token.
        │
        ▼
② Admin JS opens a hidden, mobile-width (375×812) <iframe>
   at that URL. The token is validated server-side by
   Mobilytics_Frontend_Scanner before it injects
   frontend-scanner.js into that one page load via wp_footer —
   normal visitors never receive this script.
        │
        ▼
③ frontend-scanner.js runs inside the iframe on the REAL
   rendered page (real CSS, real computed styles, real
   getBoundingClientRect() geometry) and posts its results
   back to the parent window via postMessage.
        │
        ▼
④ AJAX: mobilytics_finish_scan
   Server + client results are merged, re-sanitized,
   scored by Mobilytics_Scorer, and persisted to
   wp_options. The dashboard re-renders instantly from
   the JSON response — no full page reload.
```

This keeps the plugin **lightweight** (no headless Chrome, no third-party API, no extra server dependency) while still getting real rendered-layout data, not just static-HTML guesses.

### Scoring Model

- Each check has a **weight** (1–3) reflecting its relative importance within its category (e.g. "Viewport Meta Tag" is weighted higher than "Language Declared").
- A check's points are `Passed = 100`, `Warning = 50`, `Critical = 0`.
- A **category score** is the weight-adjusted average of its checks' points.
- The **overall score** is the average of all category scores that had at least one applicable check (categories with no relevant elements on the page — e.g. no images — are simply excluded rather than penalized).
- Thresholds for "Good" (default ≥80) and "Needs Work" (default ≥50) are configurable in Settings.

### Security

- All admin actions go through `wp_ajax_*` hooks, gated by `check_ajax_referer()` **and** `current_user_can( 'manage_options' )`.
- Every settings field is sanitized on save (`sanitize_text_field`, `sanitize_textarea_field`, `esc_url_raw`, integer casting with bounds).
- Every output is escaped at render time (`esc_html`, `esc_attr`, `esc_url`).
- Client-submitted check data (from the iframe geometry scan) is **never trusted verbatim** — it's whitelisted against known status/category values and re-sanitized server-side before being scored or stored.
- The front-end scanner script is only ever injected when a valid, single-use, 5-minute transient token is present in the URL — regular visitors never load it, and the token can't be reused after the scan completes.
- `uninstall.php` removes all plugin options and scheduled cron events on deletion.

### Performance

- A manual scan makes exactly **one** additional page load of your own site (plus up to 8 lightweight `HEAD` requests to sample image sizes) — it does not add any weight to normal visitor page loads.
- The front-end scanner script (`frontend-scanner.js`, a few KB) is only ever served during an active scan, gated by a transient token; it is not loaded for real visitors, so it has zero performance impact on your live site.
- Scheduled (cron) scans run server-side checks only, keeping unattended scans cheap.

## Architecture Decisions — Why V1 Is Scoped This Way

- **~24 checks, not 100.** Every check here was chosen because it's cheap to compute accurately and rarely false-positives. It intentionally does *not* attempt to replicate Lighthouse's Core Web Vitals lab metrics (LCP/TBT/CLS timing), which require a real performance-tracing browser session — that's a good V2 candidate via an optional PageSpeed Insights API integration, not a thing to fake with heuristics.
- **PDF via browser print, not a bundled PDF library.** Dompdf/mPDF add real weight (and their own edge cases with modern CSS) for a feature the browser already does natively and reliably. A dedicated print stylesheet (`report.css`) gets a clean one-click PDF without a new dependency.
- **No headless browser / third-party scanning API.** Keeping this dependency-free was a deliberate constraint — it needed to work on ordinary shared hosting, not require Node/Puppeteer or an external subscription.
- **Single-URL scanning in V1.** Multi-page crawling is straightforward to add (loop `start_scan()` over a sitemap) but was left out of V1 to keep the scan fast and the UI simple; it's the first roadmap item.

## Roadmap (V2+)

- [ ] Multi-page / full-site crawl with a paginated results view
- [ ] Historical score trend chart (the `mobilytics_history` option already tracks every run)
- [ ] Optional Google PageSpeed Insights API integration for real Core Web Vitals
- [ ] Emailed scheduled-scan summaries
- [ ] White-label PDF export (server-rendered, for agencies wanting pixel-perfect branded exports beyond browser print)
- [ ] Per-page-type exclusion presets (e.g. auto-skip WooCommerce checkout)

## Portfolio Case Study

**The brief:** Build a real, shippable WordPress product — not a demo script — that shows full-stack WordPress capability: PHP architecture, vanilla JS engineering, UX/performance domain knowledge, and product thinking aimed at an actual buyer (a site owner or an agency's client).

**The interesting problem:** A meaningful mobile-UX audit needs real rendered-layout data (overflow, computed font sizes, real tap-target geometry) — but the "obvious" solution (a headless browser or a third-party scanning API) would turn a "lightweight plugin" into a hosting-dependent, API-key-gated product. The two-phase architecture — PHP static analysis for everything that's visible in raw HTML, plus a token-gated hidden iframe running a small JS scanner for everything that needs real layout — solves this without adding a single external dependency, while still keeping every check backed by real data instead of guesses.

**The product thinking:** Every single check ships with both a "why it matters" (so a non-technical site owner understands the stakes) and a "how to fix it" (so it's actionable, not just diagnostic) — because the target buyer for a tool like this isn't an engineer running Lighthouse, it's a business owner who needs to know what to tell their developer. The optional branded CTA turns the same tool into a lead-generation asset for the developer running it on prospects' sites.

**What this demonstrates:**
- WordPress plugin architecture (hooks, AJAX, REST, Cron, options API, activation/uninstall lifecycle)
- Defensive security practices (nonces, capability checks, sanitization/escaping, never trusting client-submitted data)
- A from-scratch scanning engine spanning both PHP (DOM parsing) and JavaScript (live layout introspection)
- UX/design work on the admin dashboard and the client-facing report
- Product judgment: knowing what *not* to build in V1 (Lighthouse parity, a PDF library, multi-page crawling) to ship something focused and reliable

## License

GPL v2 or later — see [LICENSE](LICENSE).

---

*Mobilytics — Find what's hurting your mobile experience.*
