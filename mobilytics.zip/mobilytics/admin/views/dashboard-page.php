<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/** @var array|false $last set below for convenience in this view */
$last = Mobilytics_Audit_Engine::get_last_results();
$categories = Mobilytics_Scorer::categories();
?>
<div class="wrap mobilytics-wrap">

	<div class="mobilytics-header">
		<div class="mobilytics-header-title">
			<span class="dashicons dashicons-smartphone"></span>
			<div>
				<h1><?php esc_html_e( 'Mobilytics', 'mobilytics' ); ?></h1>
				<p class="mobilytics-tagline"><?php esc_html_e( "Find what's hurting your mobile experience.", 'mobilytics' ); ?></p>
			</div>
		</div>
		<div class="mobilytics-header-actions">
			<button type="button" id="mobilytics-run-audit" class="button button-primary button-hero">
				<span class="dashicons dashicons-update mobilytics-spin-icon" style="display:none;"></span>
				<span class="mobilytics-run-label"><?php esc_html_e( 'Run Mobile Audit', 'mobilytics' ); ?></span>
			</button>
			<p class="mobilytics-last-scan">
				<?php esc_html_e( 'Last scan:', 'mobilytics' ); ?>
				<span id="mobilytics-last-scan-time">
					<?php echo $last ? esc_html( $last['timestamp'] ) : esc_html__( 'Never', 'mobilytics' ); ?>
				</span>
			</p>
		</div>
	</div>

	<div id="mobilytics-progress" class="mobilytics-progress-banner" style="display:none;">
		<div class="mobilytics-spinner"></div>
		<span id="mobilytics-progress-text"><?php esc_html_e( 'Scanning your site…', 'mobilytics' ); ?></span>
	</div>

	<div id="mobilytics-error" class="notice notice-error" style="display:none;"><p></p></div>

	<div id="mobilytics-results-root">
		<?php require __DIR__ . '/dashboard-results-template.php'; ?>
	</div>

</div>
