<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$settings = Mobilytics_Settings::get();
?>
<div class="wrap mobilytics-wrap">
	<div class="mobilytics-header">
		<div class="mobilytics-header-title">
			<span class="dashicons dashicons-admin-generic"></span>
			<div>
				<h1><?php esc_html_e( 'Mobilytics Settings', 'mobilytics' ); ?></h1>
				<p class="mobilytics-tagline"><?php esc_html_e( 'Configure scan behavior, thresholds, branding, and lead-gen options.', 'mobilytics' ); ?></p>
			</div>
		</div>
	</div>

	<form method="post" class="mobilytics-settings-form">
		<?php wp_nonce_field( 'mobilytics_save_settings', 'mobilytics_settings_nonce' ); ?>

		<div class="mobilytics-settings-card">
			<h2><?php esc_html_e( 'Scan Behavior', 'mobilytics' ); ?></h2>

			<table class="form-table" role="presentation">
				<tr>
					<th><label for="scan_url"><?php esc_html_e( 'URL to Audit', 'mobilytics' ); ?></label></th>
					<td>
						<input type="url" class="regular-text" id="scan_url" name="scan_url" value="<?php echo esc_attr( $settings['scan_url'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Version 1 audits a single URL (typically your homepage). Multi-page crawling is planned for a future release.', 'mobilytics' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="scan_frequency"><?php esc_html_e( 'Scan Frequency', 'mobilytics' ); ?></label></th>
					<td>
						<select id="scan_frequency" name="scan_frequency">
							<?php foreach ( array( 'manual' => __( 'Manual only', 'mobilytics' ), 'daily' => __( 'Daily', 'mobilytics' ), 'weekly' => __( 'Weekly', 'mobilytics' ), 'monthly' => __( 'Monthly', 'mobilytics' ) ) as $val => $label ) : ?>
								<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $settings['scan_frequency'], $val ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Scheduled scans run server-side checks only (layout checks that require a browser run when you click "Run Mobile Audit" manually).', 'mobilytics' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="excluded_pages"><?php esc_html_e( 'Excluded Pages', 'mobilytics' ); ?></label></th>
					<td>
						<textarea id="excluded_pages" name="excluded_pages" rows="4" class="large-text" placeholder="/wp-admin/&#10;/checkout/"><?php echo esc_textarea( $settings['excluded_pages'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One URL or path per line. Matching pages will be skipped by scheduled scans.', 'mobilytics' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="mobilytics-settings-card">
			<h2><?php esc_html_e( 'Score Thresholds', 'mobilytics' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="threshold_good"><?php esc_html_e( '"Good" threshold', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="0" max="100" id="threshold_good" name="threshold_good" value="<?php echo esc_attr( $settings['threshold_good'] ); ?>" class="small-text" /> <?php esc_html_e( 'and above', 'mobilytics' ); ?></td>
				</tr>
				<tr>
					<th><label for="threshold_warning"><?php esc_html_e( '"Needs Work" threshold', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="0" max="100" id="threshold_warning" name="threshold_warning" value="<?php echo esc_attr( $settings['threshold_warning'] ); ?>" class="small-text" /> <?php esc_html_e( 'and above (below this is "Critical")', 'mobilytics' ); ?></td>
				</tr>
				<tr>
					<th><label for="min_touch_target"><?php esc_html_e( 'Minimum touch target size (px)', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="24" max="80" id="min_touch_target" name="min_touch_target" value="<?php echo esc_attr( $settings['min_touch_target'] ); ?>" class="small-text" /></td>
				</tr>
				<tr>
					<th><label for="min_tap_spacing"><?php esc_html_e( 'Minimum spacing between tap targets (px)', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="0" max="40" id="min_tap_spacing" name="min_tap_spacing" value="<?php echo esc_attr( $settings['min_tap_spacing'] ); ?>" class="small-text" /></td>
				</tr>
				<tr>
					<th><label for="min_font_size"><?php esc_html_e( 'Minimum readable font size (px)', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="8" max="24" id="min_font_size" name="min_font_size" value="<?php echo esc_attr( $settings['min_font_size'] ); ?>" class="small-text" /></td>
				</tr>
				<tr>
					<th><label for="max_elements"><?php esc_html_e( 'Max DOM elements before "excessive"', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="200" max="10000" id="max_elements" name="max_elements" value="<?php echo esc_attr( $settings['max_elements'] ); ?>" class="small-text" /></td>
				</tr>
				<tr>
					<th><label for="max_image_kb"><?php esc_html_e( 'Max image size before "oversized" (KB)', 'mobilytics' ); ?></label></th>
					<td><input type="number" min="30" max="5000" id="max_image_kb" name="max_image_kb" value="<?php echo esc_attr( $settings['max_image_kb'] ); ?>" class="small-text" /></td>
				</tr>
			</table>
		</div>

		<div class="mobilytics-settings-card">
			<h2><?php esc_html_e( 'Branding', 'mobilytics' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="agency_name"><?php esc_html_e( 'Agency / Brand Name', 'mobilytics' ); ?></label></th>
					<td><input type="text" class="regular-text" id="agency_name" name="agency_name" value="<?php echo esc_attr( $settings['agency_name'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="agency_logo_url"><?php esc_html_e( 'Logo URL', 'mobilytics' ); ?></label></th>
					<td><input type="url" class="regular-text" id="agency_logo_url" name="agency_logo_url" value="<?php echo esc_attr( $settings['agency_logo_url'] ); ?>" placeholder="https://" /></td>
				</tr>
			</table>
		</div>

		<div class="mobilytics-settings-card">
			<h2><?php esc_html_e( 'Lead Generation CTA', 'mobilytics' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Show CTA on public report', 'mobilytics' ); ?></th>
					<td><label><input type="checkbox" name="cta_enabled" value="1" <?php checked( $settings['cta_enabled'] ); ?> /> <?php esc_html_e( 'Enabled', 'mobilytics' ); ?></label></td>
				</tr>
				<tr>
					<th><label for="cta_heading"><?php esc_html_e( 'CTA Heading', 'mobilytics' ); ?></label></th>
					<td><input type="text" class="regular-text" id="cta_heading" name="cta_heading" value="<?php echo esc_attr( $settings['cta_heading'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="cta_text"><?php esc_html_e( 'CTA Text', 'mobilytics' ); ?></label></th>
					<td><textarea id="cta_text" name="cta_text" rows="3" class="large-text"><?php echo esc_textarea( $settings['cta_text'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="cta_button_label"><?php esc_html_e( 'Button Label', 'mobilytics' ); ?></label></th>
					<td><input type="text" class="regular-text" id="cta_button_label" name="cta_button_label" value="<?php echo esc_attr( $settings['cta_button_label'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="cta_contact_url"><?php esc_html_e( 'Contact / Booking URL', 'mobilytics' ); ?></label></th>
					<td><input type="url" class="regular-text" id="cta_contact_url" name="cta_contact_url" value="<?php echo esc_attr( $settings['cta_contact_url'] ); ?>" placeholder="https://yourwebsite.com/contact" /></td>
				</tr>
			</table>
		</div>

		<div class="mobilytics-settings-card">
			<h2><?php esc_html_e( 'Report Options', 'mobilytics' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Public report link', 'mobilytics' ); ?></th>
					<td>
						<label><input type="checkbox" name="report_public" value="1" <?php checked( $settings['report_public'] ); ?> /> <?php esc_html_e( 'Allow anyone with the link to view the report (no login required)', 'mobilytics' ); ?></label>
						<p class="description"><?php esc_html_e( 'Add the [mobilytics_report] shortcode to any page to display it. Turn this off to require an admin login instead.', 'mobilytics' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Show passed checks', 'mobilytics' ); ?></th>
					<td><label><input type="checkbox" name="report_show_passed" value="1" <?php checked( $settings['report_show_passed'] ); ?> /> <?php esc_html_e( 'Include passed checks in the client report (not just issues)', 'mobilytics' ); ?></label></td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save Settings', 'mobilytics' ) ); ?>
	</form>
</div>
