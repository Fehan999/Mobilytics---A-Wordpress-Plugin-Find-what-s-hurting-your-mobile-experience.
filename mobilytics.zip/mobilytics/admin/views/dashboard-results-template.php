<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the score hero + category cards + detailed accordion for a given
 * results record. $last must be set by the including file; falls back to
 * an empty state when no scan has run yet.
 */
if ( empty( $last ) || empty( $last['score'] ) ) {
	?>
	<div class="mobilytics-empty-state">
		<span class="dashicons dashicons-search"></span>
		<h2><?php esc_html_e( 'No audit yet', 'mobilytics' ); ?></h2>
		<p><?php esc_html_e( 'Click "Run Mobile Audit" above to scan your homepage for common mobile UX problems.', 'mobilytics' ); ?></p>
	</div>
	<?php
	return;
}

$score      = $last['score']['overall_score'];
$grade      = $last['score']['grade'];
$counts     = $last['score']['counts'];
$cats       = $last['score']['categories'];
$checks     = $last['checks'];

$score_class = 'critical';
if ( $score >= 80 ) {
	$score_class = 'good';
} elseif ( $score >= 50 ) {
	$score_class = 'warning';
}
?>
<div class="mobilytics-score-section">
	<div class="mobilytics-score-hero mobilytics-score-hero--<?php echo esc_attr( $score_class ); ?>">
		<div class="mobilytics-score-circle" style="--mobilytics-score: <?php echo (int) $score; ?>;">
			<svg viewBox="0 0 120 120" class="mobilytics-score-ring">
				<circle cx="60" cy="60" r="52" class="mobilytics-ring-bg" />
				<circle cx="60" cy="60" r="52" class="mobilytics-ring-fg mobilytics-ring-fg--<?php echo esc_attr( $score_class ); ?>"
					stroke-dasharray="<?php echo esc_attr( round( 326.7 * $score / 100, 1 ) ); ?> 326.7" />
			</svg>
			<div class="mobilytics-score-number">
				<strong><?php echo (int) $score; ?></strong><span>/100</span>
			</div>
		</div>
		<div class="mobilytics-score-meta">
			<div class="mobilytics-score-grade mobilytics-badge mobilytics-badge--<?php echo esc_attr( $grade['status'] ); ?>">
				<?php echo esc_html( $grade['label'] ); ?>
			</div>
			<div class="mobilytics-score-counts">
				<span class="mobilytics-count mobilytics-count--passed"><?php echo (int) $counts['passed']; ?> <?php esc_html_e( 'Passed', 'mobilytics' ); ?></span>
				<span class="mobilytics-count mobilytics-count--warning"><?php echo (int) $counts['warning']; ?> <?php esc_html_e( 'Warning', 'mobilytics' ); ?></span>
				<span class="mobilytics-count mobilytics-count--critical"><?php echo (int) $counts['critical']; ?> <?php esc_html_e( 'Critical', 'mobilytics' ); ?></span>
			</div>
			<p class="mobilytics-scanned-url"><?php echo esc_html( $last['url'] ); ?></p>
		</div>
	</div>

	<div class="mobilytics-category-grid">
		<?php foreach ( $cats as $key => $cat ) : ?>
			<?php if ( null === $cat['score'] ) continue; ?>
			<?php
			$cat_class = 'critical';
			if ( $cat['score'] >= 80 ) {
				$cat_class = 'good';
			} elseif ( $cat['score'] >= 50 ) {
				$cat_class = 'warning';
			}
			?>
			<div class="mobilytics-category-card">
				<h3><?php echo esc_html( $cat['label'] ); ?></h3>
				<div class="mobilytics-category-score mobilytics-category-score--<?php echo esc_attr( $cat_class ); ?>">
					<?php echo (int) $cat['score']; ?>
				</div>
				<div class="mobilytics-progress-bar">
					<div class="mobilytics-progress-fill mobilytics-progress-fill--<?php echo esc_attr( $cat_class ); ?>" style="width: <?php echo (int) $cat['score']; ?>%;"></div>
				</div>
				<div class="mobilytics-category-counts">
					<span class="mobilytics-dot mobilytics-dot--passed"></span> <?php echo (int) $cat['passed']; ?>
					<span class="mobilytics-dot mobilytics-dot--warning"></span> <?php echo (int) $cat['warning']; ?>
					<span class="mobilytics-dot mobilytics-dot--critical"></span> <?php echo (int) $cat['critical']; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<div class="mobilytics-detail-section">
	<h2><?php esc_html_e( 'Detailed Audit', 'mobilytics' ); ?></h2>
	<div class="mobilytics-filter-bar">
		<button type="button" class="mobilytics-filter active" data-filter="all"><?php esc_html_e( 'All', 'mobilytics' ); ?></button>
		<button type="button" class="mobilytics-filter" data-filter="critical"><?php esc_html_e( 'Critical', 'mobilytics' ); ?></button>
		<button type="button" class="mobilytics-filter" data-filter="warning"><?php esc_html_e( 'Warning', 'mobilytics' ); ?></button>
		<button type="button" class="mobilytics-filter" data-filter="passed"><?php esc_html_e( 'Passed', 'mobilytics' ); ?></button>
	</div>

	<?php foreach ( $cats as $key => $cat ) : ?>
		<?php if ( empty( $cat['checks'] ) ) continue; ?>
		<div class="mobilytics-category-group">
			<h3><?php echo esc_html( $cat['label'] ); ?></h3>
			<?php foreach ( $cat['checks'] as $check ) : ?>
				<details class="mobilytics-issue-row mobilytics-issue-row--<?php echo esc_attr( $check['status'] ); ?>" data-status="<?php echo esc_attr( $check['status'] ); ?>">
					<summary>
						<span class="mobilytics-badge mobilytics-badge--<?php echo esc_attr( $check['status'] ); ?>"><?php echo esc_html( ucfirst( $check['status'] ) ); ?></span>
						<strong><?php echo esc_html( $check['label'] ); ?></strong>
						<span class="mobilytics-issue-message"><?php echo esc_html( $check['message'] ); ?></span>
					</summary>
					<div class="mobilytics-issue-body">
						<?php if ( ! empty( $check['why'] ) ) : ?>
							<p><strong><?php esc_html_e( 'Why it matters:', 'mobilytics' ); ?></strong> <?php echo esc_html( $check['why'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $check['fix'] ) ) : ?>
							<p><strong><?php esc_html_e( 'How to fix it:', 'mobilytics' ); ?></strong> <?php echo esc_html( $check['fix'] ); ?></p>
						<?php endif; ?>
					</div>
				</details>
			<?php endforeach; ?>
		</div>
	<?php endforeach; ?>
</div>
