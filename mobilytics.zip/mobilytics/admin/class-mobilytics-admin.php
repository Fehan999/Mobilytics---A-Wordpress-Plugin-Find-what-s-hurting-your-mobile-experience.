<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Admin
 *
 * Registers the wp-admin menu, dashboard page, and settings page, and
 * enqueues the admin CSS/JS only on Mobilytics screens.
 */
class Mobilytics_Admin {

	private $dashboard_hook;
	private $settings_hook;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function register_menu() {
		$this->dashboard_hook = add_menu_page(
			__( 'Mobilytics', 'mobilytics' ),
			__( 'Mobilytics', 'mobilytics' ),
			MOBILYTICS_CAPABILITY,
			'mobilytics',
			array( $this, 'render_dashboard' ),
			'dashicons-smartphone',
			58
		);

		$this->settings_hook = add_submenu_page(
			'mobilytics',
			__( 'Mobilytics Settings', 'mobilytics' ),
			__( 'Settings', 'mobilytics' ),
			MOBILYTICS_CAPABILITY,
			'mobilytics-settings',
			array( $this, 'render_settings' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( ! in_array( $hook, array( $this->dashboard_hook, $this->settings_hook ), true ) ) {
			return;
		}

		wp_enqueue_style(
			'mobilytics-admin',
			MOBILYTICS_URL . 'assets/css/admin.css',
			array(),
			MOBILYTICS_VERSION
		);

		wp_enqueue_script(
			'mobilytics-admin',
			MOBILYTICS_URL . 'assets/js/admin.js',
			array(),
			MOBILYTICS_VERSION,
			true
		);

		$last = class_exists( 'Mobilytics_Audit_Engine' )
			? Mobilytics_Audit_Engine::get_last_results()
			: false;

		$settings = Mobilytics_Settings::get();

		wp_localize_script(
			'mobilytics-admin',
			'MobilyticsAdmin',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( Mobilytics_Ajax::NONCE_ACTION ),
				'restReport'  => esc_url_raw( rest_url( 'mobilytics/v1/report' ) ),
				'scanUrl'     => $settings['scan_url'],
				'lastResults' => $last ? $last : null,
				'categories'  => Mobilytics_Scorer::categories(),
				'i18n'        => array(
					'running'       => __( 'Scanning your site…', 'mobilytics' ),
					'loadingClient' => __( 'Checking layout on a simulated mobile screen…', 'mobilytics' ),
					'error'         => __( 'Something went wrong running the audit. Please try again.', 'mobilytics' ),
					'runAudit'      => __( 'Run Mobile Audit', 'mobilytics' ),
				),
			)
		);
	}

	public function render_dashboard() {
		if ( ! current_user_can( MOBILYTICS_CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'mobilytics' ) );
		}
		require MOBILYTICS_PATH . 'admin/views/dashboard-page.php';
	}

	public function render_settings() {
		if ( ! current_user_can( MOBILYTICS_CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'mobilytics' ) );
		}

		if (
			isset( $_POST['mobilytics_settings_nonce'] ) &&
			wp_verify_nonce(
				sanitize_text_field( wp_unslash( $_POST['mobilytics_settings_nonce'] ) ),
				'mobilytics_save_settings'
			)
		) {
			Mobilytics_Settings::update( wp_unslash( $_POST ) );
			echo '<div class="notice notice-success is-dismissible"><p>'
				. esc_html__( 'Mobilytics settings saved.', 'mobilytics' )
				. '</p></div>';
		}

		require MOBILYTICS_PATH . 'admin/views/settings-page.php';
	}
}