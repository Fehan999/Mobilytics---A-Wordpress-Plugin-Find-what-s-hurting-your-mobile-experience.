<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Audit_Engine
 *
 * Coordinates a full audit run: fetch HTML, run server-side checks,
 * (optionally merge client-side geometry checks sent up from the browser),
 * score everything, and persist the results.
 */
class Mobilytics_Audit_Engine {

	/**
	 * Step 1 of a scan: fetch the page and run every server-side check.
	 * Returns the server checks plus a fresh scan token the admin JS
	 * will use to run the client-side geometry scan in a hidden iframe.
	 */
	public static function start_scan( $url = '' ) {
		$settings = Mobilytics_Settings::get();
		$url      = $url ? esc_url_raw( $url ) : $settings['scan_url'];

		if ( Mobilytics_Settings::is_excluded( $url ) ) {
			return new WP_Error( 'mobilytics_excluded', __( 'This URL is in your excluded pages list.', 'mobilytics' ) );
		}

		$response = wp_remote_get( $url, array(
			'timeout'    => 15,
			'user-agent' => 'Mobilytics-Scanner/1.0 (+' . home_url() . ') Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)',
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 400 ) {
			return new WP_Error( 'mobilytics_fetch_failed', sprintf( __( 'Could not fetch the page (HTTP %d).', 'mobilytics' ), $code ) );
		}

		$html = wp_remote_retrieve_body( $response );

		$checks_engine  = new Mobilytics_Checks( $html );
		$server_checks  = $checks_engine->run_all();

		$token = Mobilytics_Frontend_Scanner::generate_token();

		return array(
			'url'            => $url,
			'server_checks'  => $server_checks,
			'scan_token'     => $token,
			'scan_iframe_url'=> add_query_arg(
				array(
					Mobilytics_Frontend_Scanner::QUERY_VAR => 1,
					'token' => $token,
				),
				$url
			),
		);
	}

	/**
	 * Step 2: merge client checks (from the iframe scan) with the server
	 * checks from step 1, score the combined set, and persist.
	 */
	public static function finish_scan( $url, array $server_checks, array $client_checks, $token = '' ) {
		if ( $token ) {
			Mobilytics_Frontend_Scanner::consume_token( $token );
		}

		$all_checks = array_merge( $server_checks, self::sanitize_client_checks( $client_checks ) );
		$scored     = Mobilytics_Scorer::score( $all_checks );

		$record = array(
			'url'       => esc_url_raw( $url ),
			'timestamp' => current_time( 'mysql' ),
			'timestamp_gmt' => current_time( 'mysql', true ),
			'checks'    => $all_checks,
			'score'     => $scored,
		);

		update_option( MOBILYTICS_OPTION_RESULTS, $record );
		self::append_history( $record );

		return $record;
	}

	/**
	 * Client (JS) results arrive as untrusted input over AJAX — sanitize
	 * every field defensively before it's stored or displayed.
	 */
	private static function sanitize_client_checks( array $client_checks ) {
		$allowed_status     = array( 'passed', 'warning', 'critical' );
		$allowed_categories = array_keys( Mobilytics_Scorer::categories() );
		$clean = array();

		foreach ( $client_checks as $check ) {
			if ( ! is_array( $check ) ) {
				continue;
			}
			$status   = isset( $check['status'] ) && in_array( $check['status'], $allowed_status, true ) ? $check['status'] : 'warning';
			$category = isset( $check['category'] ) && in_array( $check['category'], $allowed_categories, true ) ? $check['category'] : 'responsive';

			$clean[] = array(
				'id'       => isset( $check['id'] ) ? sanitize_key( $check['id'] ) : sanitize_key( uniqid( 'check_' ) ),
				'label'    => isset( $check['label'] ) ? sanitize_text_field( $check['label'] ) : __( 'Untitled Check', 'mobilytics' ),
				'category' => $category,
				'status'   => $status,
				'message'  => isset( $check['message'] ) ? sanitize_text_field( $check['message'] ) : '',
				'why'      => isset( $check['why'] ) ? sanitize_textarea_field( $check['why'] ) : '',
				'fix'      => isset( $check['fix'] ) ? sanitize_textarea_field( $check['fix'] ) : '',
				'weight'   => isset( $check['weight'] ) ? max( 1, min( 5, (int) $check['weight'] ) ) : 1,
				'source'   => 'client',
			);
		}
		return $clean;
	}

	private static function append_history( array $record ) {
		$history = get_option( MOBILYTICS_OPTION_HISTORY, array() );
		if ( ! is_array( $history ) ) {
			$history = array();
		}
		$history[] = array(
			'timestamp' => $record['timestamp'],
			'url'       => $record['url'],
			'overall_score' => $record['score']['overall_score'],
		);
		// Keep the last 50 runs only.
		if ( count( $history ) > 50 ) {
			$history = array_slice( $history, -50 );
		}
		update_option( MOBILYTICS_OPTION_HISTORY, $history );
	}

	/**
	 * Called by WP-Cron for scheduled scans. Runs a server-only scan
	 * (no browser available in a cron context to run the JS geometry
	 * checks), which still covers the majority of checks.
	 */
	public static function run_scheduled() {
		$result = self::start_scan();
		if ( is_wp_error( $result ) ) {
			return;
		}
		self::finish_scan( $result['url'], $result['server_checks'], array() );
	}

	public static function get_last_results() {
		return get_option( MOBILYTICS_OPTION_RESULTS, false );
	}

	public static function get_history() {
		return get_option( MOBILYTICS_OPTION_HISTORY, array() );
	}
}
