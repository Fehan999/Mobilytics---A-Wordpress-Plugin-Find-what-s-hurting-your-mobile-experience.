<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Ajax
 *
 * All admin-facing AJAX endpoints. Every handler checks the nonce and the
 * user capability before doing anything.
 */
class Mobilytics_Ajax {

	const NONCE_ACTION = 'mobilytics_ajax';

	public function __construct() {
		add_action( 'wp_ajax_mobilytics_start_scan', array( $this, 'start_scan' ) );
		add_action( 'wp_ajax_mobilytics_finish_scan', array( $this, 'finish_scan' ) );
		add_action( 'wp_ajax_mobilytics_save_settings', array( $this, 'save_settings' ) );
	}

	private function guard() {
		if ( ! current_user_can( MOBILYTICS_CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'mobilytics' ) ), 403 );
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}

	public function start_scan() {
		$this->guard();

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';

		$result = Mobilytics_Audit_Engine::start_scan( $url );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( $result );
	}

	public function finish_scan() {
		$this->guard();

		$url   = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';

		$server_checks_raw = isset( $_POST['server_checks'] ) ? wp_unslash( $_POST['server_checks'] ) : '[]';
		$client_checks_raw = isset( $_POST['client_checks'] ) ? wp_unslash( $_POST['client_checks'] ) : '[]';

		$server_checks = json_decode( $server_checks_raw, true );
		$client_checks = json_decode( $client_checks_raw, true );

		if ( ! is_array( $server_checks ) ) {
			$server_checks = array();
		}
		if ( ! is_array( $client_checks ) ) {
			$client_checks = array();
		}

		// Both sets crossed a client boundary — sanitize both.
		$server_checks = $this->sanitize_roundtripped_checks( $server_checks );
		$client_checks = $this->sanitize_roundtripped_checks( $client_checks );

		$record = Mobilytics_Audit_Engine::finish_scan( $url, $server_checks, $client_checks, $token );

		wp_send_json_success( $record );
	}

	private function sanitize_roundtripped_checks( array $checks ) {
		$allowed_status     = array( 'passed', 'warning', 'critical' );
		$allowed_categories = array_keys( Mobilytics_Scorer::categories() );
		$clean              = array();

		foreach ( $checks as $check ) {
			if ( ! is_array( $check ) ) {
				continue;
			}
			$status   = isset( $check['status'] ) && in_array( $check['status'], $allowed_status, true ) ? $check['status'] : 'warning';
			$category = isset( $check['category'] ) && in_array( $check['category'], $allowed_categories, true ) ? $check['category'] : 'responsive';

			$clean[] = array(
				'id'       => isset( $check['id'] ) ? sanitize_key( $check['id'] ) : sanitize_key( uniqid( 'check_' ) ),
				'label'    => isset( $check['label'] ) ? sanitize_text_field( $check['label'] ) : '',
				'category' => $category,
				'status'   => $status,
				'message'  => isset( $check['message'] ) ? sanitize_text_field( $check['message'] ) : '',
				'why'      => isset( $check['why'] ) ? sanitize_textarea_field( $check['why'] ) : '',
				'fix'      => isset( $check['fix'] ) ? sanitize_textarea_field( $check['fix'] ) : '',
				'weight'   => isset( $check['weight'] ) ? max( 1, min( 5, (int) $check['weight'] ) ) : 1,
				'source'   => isset( $check['source'] ) && 'client' === $check['source'] ? 'client' : 'server',
			);
		}
		return $clean;
	}

	public function save_settings() {
		$this->guard();

		$raw   = isset( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array();
		$saved = Mobilytics_Settings::update( $raw );

		wp_send_json_success( array( 'settings' => $saved ) );
	}
}