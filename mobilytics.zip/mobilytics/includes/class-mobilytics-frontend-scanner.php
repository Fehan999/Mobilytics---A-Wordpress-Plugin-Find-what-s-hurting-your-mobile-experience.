<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Frontend_Scanner
 *
 * The admin dashboard opens the live front-end page inside a hidden,
 * mobile-width iframe with a one-time scan token in the query string.
 * This class checks for that token (validated against a short-lived
 * transient created by the admin JS via AJAX) and, only when valid,
 * prints the frontend-scanner.js config + script tag into wp_footer.
 *
 * The scanner never runs for normal visitors — no token, no script.
 */
class Mobilytics_Frontend_Scanner {

	const QUERY_VAR = 'mobilytics_scan';

	public function __construct() {
		add_action( 'wp_footer', array( $this, 'maybe_inject' ), 999 );
	}

	public function maybe_inject() {
		if ( is_admin() ) {
			return;
		}

		if ( ! isset( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}

		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		if ( '' === $token || ! self::is_valid_token( $token ) ) {
			return;
		}

		$settings = Mobilytics_Settings::get();
		?>
		<script>
			window.MobilyticsConfig = {
				token: <?php echo wp_json_encode( $token ); ?>,
				minFont: <?php echo (int) $settings['min_font_size']; ?>,
				minTarget: <?php echo (int) $settings['min_touch_target']; ?>,
				minSpacing: <?php echo (int) $settings['min_tap_spacing']; ?>,
				maxElements: <?php echo (int) $settings['max_elements']; ?>
			};
		</script>
		<script src="<?php echo esc_url( MOBILYTICS_URL . 'assets/js/frontend-scanner.js' ); ?>?ver=<?php echo esc_attr( MOBILYTICS_VERSION ); ?>"></script>
		<?php
	}

	/**
	 * Create a short-lived, single-use scan token. Called by the AJAX
	 * handler right before it hands the iframe URL to the admin JS.
	 */
	public static function generate_token() {
		$token = wp_generate_password( 32, false, false );
		set_transient( 'mobilytics_scan_token_' . $token, 1, 5 * MINUTE_IN_SECONDS );
		return $token;
	}

	public static function is_valid_token( $token ) {
		return (bool) get_transient( 'mobilytics_scan_token_' . $token );
	}

	public static function consume_token( $token ) {
		delete_transient( 'mobilytics_scan_token_' . $token );
	}
}
