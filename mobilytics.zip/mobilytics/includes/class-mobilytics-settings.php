<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles reading, writing, defaulting and sanitizing plugin settings.
 */
class Mobilytics_Settings {

	/**
	 * Default settings values.
	 */
	public static function defaults() {
		return array(
			'scan_frequency'      => 'manual',        // manual | daily | weekly | monthly
			'excluded_pages'      => '',               // newline separated list of URLs or paths
			'threshold_good'      => 80,                // score >= this => "Good"
			'threshold_warning'   => 50,                // score >= this and < good => "Needs Work"; below => "Critical"
			'scan_url'            => home_url( '/' ),   // which URL to audit
			'max_elements'        => 1500,              // DOM element count considered "excessive"
			'min_font_size'       => 12,                 // px, below this = too small
			'min_touch_target'    => 44,                 // px, WCAG/Apple/Google recommendation
			'min_tap_spacing'     => 8,                  // px, minimum gap between tap targets
			'max_image_kb'        => 300,                 // per-image soft limit before "oversized"
			// Branding / lead-gen.
			'agency_name'         => get_bloginfo( 'name' ),
			'agency_logo_url'     => '',
			'cta_enabled'         => true,
			'cta_heading'         => __( 'Need help fixing these issues?', 'mobilytics' ),
			'cta_text'            => __( "We build fast, mobile-friendly WordPress sites. Let's fix these problems together.", 'mobilytics' ),
			'cta_button_label'    => __( 'Get a Free Quote', 'mobilytics' ),
			'cta_contact_url'     => '',
			// Report options.
			'report_public'       => true,   // allow a public, unauthenticated report link
			'report_show_passed'  => true,
			'report_show_scores'  => true,
		);
	}

	public static function get() {
		$stored = get_option( MOBILYTICS_OPTION_SETTINGS, array() );
		return wp_parse_args( $stored, self::defaults() );
	}

	public static function update( array $new_values ) {
		$sanitized = self::sanitize( $new_values );
		update_option( MOBILYTICS_OPTION_SETTINGS, $sanitized );
		return $sanitized;
	}

	/**
	 * Sanitize a raw settings array (e.g. from $_POST).
	 */
	public static function sanitize( array $input ) {
		$defaults = self::defaults();
		$out      = self::get();

		if ( isset( $input['scan_frequency'] ) && in_array( $input['scan_frequency'], array( 'manual', 'daily', 'weekly', 'monthly' ), true ) ) {
			$out['scan_frequency'] = $input['scan_frequency'];
		}

		if ( isset( $input['excluded_pages'] ) ) {
			$lines = preg_split( '/\r\n|\r|\n/', (string) $input['excluded_pages'] );
			$lines = array_filter( array_map( 'trim', $lines ) );
			$lines = array_map( 'sanitize_text_field', $lines );
			$out['excluded_pages'] = implode( "\n", $lines );
		}

		foreach ( array( 'threshold_good', 'threshold_warning', 'max_elements', 'min_font_size', 'min_touch_target', 'min_tap_spacing', 'max_image_kb' ) as $numeric_key ) {
			if ( isset( $input[ $numeric_key ] ) ) {
				$out[ $numeric_key ] = max( 0, (int) $input[ $numeric_key ] );
			}
		}

		if ( isset( $input['scan_url'] ) ) {
			$url = esc_url_raw( trim( $input['scan_url'] ) );
			$out['scan_url'] = $url ? $url : $defaults['scan_url'];
		}

		if ( isset( $input['agency_name'] ) ) {
			$out['agency_name'] = sanitize_text_field( $input['agency_name'] );
		}
		if ( isset( $input['agency_logo_url'] ) ) {
			$out['agency_logo_url'] = esc_url_raw( $input['agency_logo_url'] );
		}
		if ( isset( $input['cta_heading'] ) ) {
			$out['cta_heading'] = sanitize_text_field( $input['cta_heading'] );
		}
		if ( isset( $input['cta_text'] ) ) {
			$out['cta_text'] = sanitize_textarea_field( $input['cta_text'] );
		}
		if ( isset( $input['cta_button_label'] ) ) {
			$out['cta_button_label'] = sanitize_text_field( $input['cta_button_label'] );
		}
		if ( isset( $input['cta_contact_url'] ) ) {
			$out['cta_contact_url'] = esc_url_raw( $input['cta_contact_url'] );
		}

		foreach ( array( 'cta_enabled', 'report_public', 'report_show_passed', 'report_show_scores' ) as $bool_key ) {
			$out[ $bool_key ] = ! empty( $input[ $bool_key ] );
		}

		return $out;
	}

	/**
	 * Is a given URL/path excluded from scanning?
	 */
	public static function is_excluded( $url ) {
		$settings = self::get();
		if ( empty( $settings['excluded_pages'] ) ) {
			return false;
		}
		$path_needle = wp_parse_url( $url, PHP_URL_PATH );
		$lines       = array_filter( array_map( 'trim', explode( "\n", $settings['excluded_pages'] ) ) );

		foreach ( $lines as $line ) {
			if ( '' === $line ) {
				continue;
			}
			if ( false !== strpos( $url, $line ) || ( $path_needle && false !== strpos( $path_needle, $line ) ) ) {
				return true;
			}
		}
		return false;
	}
}
