<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_REST
 *
 * Exposes a read-only endpoint used by the public /mobile-ux-report/ page
 * to render the client-friendly summary. Deliberately public (no auth)
 * only when "report_public" is enabled in settings, mirroring how a
 * shareable client report would work; it returns a redacted subset of
 * data (no raw settings, no internal option names).
 */
class Mobilytics_REST {

	const NAMESPACE_ = 'mobilytics/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route( self::NAMESPACE_, '/report', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_report' ),
			'permission_callback' => array( $this, 'permission_check' ),
		) );
	}

	public function permission_check() {
		$settings = Mobilytics_Settings::get();
		if ( ! empty( $settings['report_public'] ) ) {
			return true;
		}
		return current_user_can( MOBILYTICS_CAPABILITY );
	}

	public function get_report( WP_REST_Request $request ) {
		$results = Mobilytics_Audit_Engine::get_last_results();
		if ( empty( $results ) ) {
			return new WP_Error( 'mobilytics_no_scan', __( 'No scan has been run yet.', 'mobilytics' ), array( 'status' => 404 ) );
		}

		$settings = Mobilytics_Settings::get();

		return array(
			'site_name'   => get_bloginfo( 'name' ),
			'url'         => $results['url'],
			'timestamp'   => $results['timestamp'],
			'score'       => $results['score'],
			'checks'      => $settings['report_show_passed'] ? $results['checks'] : array_values( array_filter( $results['checks'], function ( $c ) {
				return 'passed' !== $c['status'];
			} ) ),
			'branding'    => array(
				'agency_name'      => $settings['agency_name'],
				'agency_logo_url'  => $settings['agency_logo_url'],
			),
			'cta'         => $settings['cta_enabled'] ? array(
				'heading'      => $settings['cta_heading'],
				'text'         => $settings['cta_text'],
				'button_label' => $settings['cta_button_label'],
				'contact_url'  => $settings['cta_contact_url'],
			) : null,
		);
	}
}
