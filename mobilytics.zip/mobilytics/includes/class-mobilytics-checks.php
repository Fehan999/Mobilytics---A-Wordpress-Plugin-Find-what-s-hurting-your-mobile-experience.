<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Checks
 *
 * Runs the "static" half of the audit: checks that can be derived from the
 * raw HTML response and WordPress settings alone, without a real browser.
 * (The other half — layout/geometry checks that need a rendered page — is
 * handled client-side by assets/js/frontend-scanner.js, see
 * class-mobilytics-frontend-scanner.php.)
 *
 * Every check returns an array:
 * [
 *   'id'          => string,
 *   'label'       => string,
 *   'category'    => string,
 *   'status'      => 'passed' | 'warning' | 'critical',
 *   'message'     => string (what we found),
 *   'why'         => string (why it matters),
 *   'fix'         => string (how to fix it),
 *   'weight'      => int (relative importance within its category, 1-3)
 * ]
 */
class Mobilytics_Checks {

	/** @var string Raw HTML of the fetched page. */
	private $html;

	/** @var DOMDocument */
	private $dom;

	/** @var DOMXPath */
	private $xpath;

	/** @var array Settings snapshot. */
	private $settings;

	public function __construct( $html ) {
		$this->html     = (string) $html;
		$this->settings = Mobilytics_Settings::get();

		$this->dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$this->dom->loadHTML( '<?xml encoding="utf-8" ?>' . $this->html );
		libxml_clear_errors();
		$this->xpath = new DOMXPath( $this->dom );
	}

	/**
	 * Run every static check and return a flat array of results.
	 */
	public function run_all() {
		$results = array();

		$results[] = $this->check_viewport_meta();
		$results[] = $this->check_media_queries();
		$results[] = $this->check_fixed_width_inline();

		$results[] = $this->check_font_size_hint();
		$results[] = $this->check_line_length_hint();

		$results[] = $this->check_images_missing_dimensions();
		$results[] = $this->check_images_missing_alt();
		$results[] = $this->check_images_oversized();

		$results[] = $this->check_render_blocking_resources();
		$results[] = $this->check_dom_element_count();
		$results[] = $this->check_page_weight();

		$results[] = $this->check_nav_menu_size();
		$results[] = $this->check_hamburger_present();

		$results[] = $this->check_form_inputs();
		$results[] = $this->check_popup_indicators();

		$results[] = $this->check_cta_clarity();
		$results[] = $this->check_meta_title_description();
		$results[] = $this->check_lang_attribute();
		$results[] = $this->check_tap_highlight_and_zoom();

		return array_values( array_filter( $results ) );
	}

	// -----------------------------------------------------------------
	// RESPONSIVE DESIGN
	// -----------------------------------------------------------------

	private function check_viewport_meta() {
		$nodes = $this->xpath->query( '//meta[@name="viewport"]' );
		if ( 0 === $nodes->length ) {
			return $this->result(
				'viewport_meta', __( 'Viewport Meta Tag', 'mobilytics' ), 'responsive', 'critical',
				__( 'No viewport meta tag was found in the page <head>.', 'mobilytics' ),
				__( 'Without a viewport tag, mobile browsers render the page at desktop width and shrink it, making text unreadable and forcing users to pinch-zoom.', 'mobilytics' ),
				__( 'Add <meta name="viewport" content="width=device-width, initial-scale=1"> inside your theme\'s <head> (most themes already support this — check Appearance → Theme Editor → header.php, or your page-builder\'s header settings).', 'mobilytics' ),
				3
			);
		}
		$content = $nodes->item( 0 )->getAttribute( 'content' );
		if ( false === strpos( $content, 'width=device-width' ) ) {
			return $this->result(
				'viewport_meta', __( 'Viewport Meta Tag', 'mobilytics' ), 'responsive', 'warning',
				sprintf( __( 'A viewport tag exists but is misconfigured: "%s".', 'mobilytics' ), esc_html( $content ) ),
				__( 'A misconfigured viewport can still cause zooming issues or block users from pinch-zooming when they need to (an accessibility problem).', 'mobilytics' ),
				__( 'Use content="width=device-width, initial-scale=1" and avoid user-scalable=no, which blocks accessibility zoom.', 'mobilytics' ),
				2
			);
		}
		if ( false !== strpos( $content, 'user-scalable=no' ) || false !== strpos( $content, 'maximum-scale=1' ) ) {
			return $this->result(
				'viewport_meta', __( 'Viewport Meta Tag', 'mobilytics' ), 'responsive', 'warning',
				__( 'Viewport tag blocks pinch-zoom (user-scalable=no or maximum-scale=1).', 'mobilytics' ),
				__( 'Blocking zoom prevents low-vision users from magnifying content — a common accessibility complaint and a mobile-friendliness signal.', 'mobilytics' ),
				__( 'Remove user-scalable=no and maximum-scale=1 from the viewport meta tag.', 'mobilytics' ),
				2
			);
		}
		return $this->result(
			'viewport_meta', __( 'Viewport Meta Tag', 'mobilytics' ), 'responsive', 'passed',
			__( 'Viewport meta tag is present and correctly configured.', 'mobilytics' ),
			__( 'This tells mobile browsers to render at device width instead of shrinking a desktop layout.', 'mobilytics' ),
			'', 3
		);
	}

	private function check_media_queries() {
		// Heuristic: look for @media in inline <style> blocks and linked stylesheet URLs
		// (we can't fetch every external stylesheet without extra requests, so this is a soft signal).
		$inline_hit = false;
		foreach ( $this->xpath->query( '//style' ) as $style_node ) {
			if ( false !== stripos( $style_node->textContent, '@media' ) ) {
				$inline_hit = true;
				break;
			}
		}

		$has_responsive_class_hints = (bool) preg_match( '/\b(container-fluid|is-mobile|responsive|wp-block)\b/i', $this->html );

		if ( $inline_hit || $has_responsive_class_hints ) {
			return $this->result(
				'media_queries', __( 'Responsive CSS Detected', 'mobilytics' ), 'responsive', 'passed',
				__( 'Responsive CSS patterns (media queries or responsive framework classes) were detected.', 'mobilytics' ),
				__( 'Media queries let your layout adapt to different screen sizes instead of staying a fixed desktop width.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'media_queries', __( 'Responsive CSS Detected', 'mobilytics' ), 'responsive', 'warning',
			__( 'No obvious responsive CSS (media queries) detected in inline styles or markup.', 'mobilytics' ),
			__( 'This is a soft signal only — many responsive stylesheets are loaded externally. But if your theme genuinely has no media queries, mobile visitors likely see a shrunk desktop layout.', 'mobilytics' ),
			__( 'Confirm your theme is advertised as "responsive." If not, switch to a modern responsive theme or add mobile-specific CSS breakpoints (e.g. @media (max-width: 480px) { ... }).', 'mobilytics' ),
			1
		);
	}

	private function check_fixed_width_inline() {
		$offenders = array();
		foreach ( $this->xpath->query( '//*[@style]' ) as $node ) {
			$style = $node->getAttribute( 'style' );
			if ( preg_match( '/width\s*:\s*(\d{3,5})px/i', $style, $m ) ) {
				$px = (int) $m[1];
				if ( $px > 420 ) { // wider than a typical small mobile viewport
					$offenders[] = $node->nodeName . ' (width:' . $px . 'px)';
				}
			}
		}

		if ( empty( $offenders ) ) {
			return $this->result(
				'fixed_width', __( 'Fixed-Width Elements', 'mobilytics' ), 'responsive', 'passed',
				__( 'No inline fixed-width elements wider than a mobile viewport were found.', 'mobilytics' ),
				__( 'Fixed pixel widths (e.g. width:900px) don\'t shrink on small screens and cause horizontal scrolling.', 'mobilytics' ),
				'', 2
			);
		}

		$status = count( $offenders ) > 3 ? 'critical' : 'warning';
		return $this->result(
			'fixed_width', __( 'Fixed-Width Elements', 'mobilytics' ), 'responsive', $status,
			sprintf( __( 'Found %d element(s) with a fixed pixel width, e.g. %s.', 'mobilytics' ), count( $offenders ), esc_html( $offenders[0] ) ),
			__( 'Elements wider than the screen force horizontal scrolling or overflow, breaking the mobile layout.', 'mobilytics' ),
			__( 'Replace fixed pixel widths with max-width, percentages, or CSS Grid/Flexbox so elements shrink to fit the screen.', 'mobilytics' ),
			2
		);
	}

	// -----------------------------------------------------------------
	// READABILITY (initial hints; refined further by the JS scan)
	// -----------------------------------------------------------------

	private function check_font_size_hint() {
		$small_hits = 0;
		foreach ( $this->xpath->query( '//*[@style]' ) as $node ) {
			$style = $node->getAttribute( 'style' );
			if ( preg_match( '/font-size\s*:\s*(\d{1,2})px/i', $style, $m ) ) {
				if ( (int) $m[1] < (int) $this->settings['min_font_size'] ) {
					$small_hits++;
				}
			}
		}

		if ( 0 === $small_hits ) {
			return $this->result(
				'font_size', __( 'Text Size', 'mobilytics' ), 'readability', 'passed',
				__( 'No inline styles set text smaller than the recommended minimum.', 'mobilytics' ),
				__( 'Text under 12px is hard to read on mobile without zooming.', 'mobilytics' ),
				'', 2
			);
		}

		return $this->result(
			'font_size', __( 'Text Size', 'mobilytics' ), 'readability', $small_hits > 3 ? 'critical' : 'warning',
			sprintf( __( 'Found %d element(s) with inline font-size under %dpx.', 'mobilytics' ), $small_hits, (int) $this->settings['min_font_size'] ),
			__( 'Small text forces visitors to pinch-zoom to read, which is one of the most common mobile usability complaints.', 'mobilytics' ),
			sprintf( __( 'Set a base font size of at least %dpx (16px is a comfortable default) for body text on mobile.', 'mobilytics' ), (int) $this->settings['min_font_size'] ),
			2
		);
	}

	private function check_line_length_hint() {
		$paragraphs = $this->xpath->query( '//p' );
		$long_count = 0;
		$total      = 0;
		foreach ( $paragraphs as $p ) {
			$text = trim( wp_strip_all_tags( $p->textContent ) );
			if ( '' === $text ) {
				continue;
			}
			$total++;
			if ( mb_strlen( $text ) > 0 ) {
				$longest_word_free = str_word_count( $text );
				if ( $longest_word_free > 0 && ( mb_strlen( $text ) / max( 1, substr_count( $text, ' ' ) + 1 ) ) > 12 ) {
					// average "word" length abnormally high can indicate no wrapping opportunities (e.g. long URLs)
					$long_count++;
				}
			}
		}

		if ( 0 === $total ) {
			return null; // nothing to evaluate, skip rather than force a result.
		}

		if ( $long_count / max( 1, $total ) < 0.15 ) {
			return $this->result(
				'line_length', __( 'Readable Text Blocks', 'mobilytics' ), 'readability', 'passed',
				__( 'Paragraph text appears to wrap normally without long unbroken strings.', 'mobilytics' ),
				__( 'Long unbroken strings (URLs, unspaced text) cause horizontal overflow on narrow screens.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'line_length', __( 'Readable Text Blocks', 'mobilytics' ), 'readability', 'warning',
			__( 'Some paragraphs contain unusually long unbroken text runs.', 'mobilytics' ),
			__( 'Long unbroken strings can force horizontal scrolling on narrow screens if word-wrap is not enabled.', 'mobilytics' ),
			__( 'Add CSS `overflow-wrap: break-word;` to body text and avoid pasting raw long URLs directly into content.', 'mobilytics' ),
			1
		);
	}

	// -----------------------------------------------------------------
	// IMAGES
	// -----------------------------------------------------------------

	private function check_images_missing_dimensions() {
		$imgs = $this->xpath->query( '//img' );
		$missing = 0;
		$total   = $imgs->length;
		foreach ( $imgs as $img ) {
			if ( ! $img->hasAttribute( 'width' ) || ! $img->hasAttribute( 'height' ) ) {
				$missing++;
			}
		}
		if ( 0 === $total ) {
			return null;
		}
		if ( 0 === $missing ) {
			return $this->result(
				'img_dimensions', __( 'Image Dimensions Set', 'mobilytics' ), 'images', 'passed',
				__( 'All images declare width and height attributes.', 'mobilytics' ),
				__( 'Explicit dimensions let the browser reserve space before the image loads, preventing layout jank (Cumulative Layout Shift).', 'mobilytics' ),
				'', 2
			);
		}
		$status = ( $missing / $total ) > 0.5 ? 'critical' : 'warning';
		return $this->result(
			'img_dimensions', __( 'Image Dimensions Set', 'mobilytics' ), 'images', $status,
			sprintf( __( '%1$d of %2$d images are missing width/height attributes.', 'mobilytics' ), $missing, $total ),
			__( 'Images without declared dimensions cause the page to visibly jump as they load — one of the most common mobile layout-shift complaints, and a Core Web Vitals (CLS) penalty.', 'mobilytics' ),
			__( 'Add width and height attributes to every <img> tag (WordPress does this automatically for images added through the Media Library — re-insert images that were hand-coded or pasted from external HTML).', 'mobilytics' ),
			2
		);
	}

	private function check_images_missing_alt() {
		$imgs = $this->xpath->query( '//img' );
		$missing = 0;
		$total   = $imgs->length;
		foreach ( $imgs as $img ) {
			if ( ! $img->hasAttribute( 'alt' ) || '' === trim( $img->getAttribute( 'alt' ) ) ) {
				$missing++;
			}
		}
		if ( 0 === $total ) {
			return null;
		}
		if ( 0 === $missing ) {
			return $this->result(
				'img_alt', __( 'Image Alt Text', 'mobilytics' ), 'images', 'passed',
				__( 'All images have descriptive alt text.', 'mobilytics' ),
				__( 'Alt text helps screen-reader users understand images and helps images rank in mobile image search.', 'mobilytics' ),
				'', 2
			);
		}
		$status = ( $missing / $total ) > 0.5 ? 'critical' : 'warning';
		return $this->result(
			'img_alt', __( 'Image Alt Text', 'mobilytics' ), 'images', $status,
			sprintf( __( '%1$d of %2$d images are missing alt text.', 'mobilytics' ), $missing, $total ),
			__( 'Missing alt text is an accessibility failure for screen-reader users and a missed opportunity for mobile image search visibility.', 'mobilytics' ),
			__( 'Add a short, descriptive alt attribute to each image in the Media Library (Edit → Alternative Text). Purely decorative images can use alt="".', 'mobilytics' ),
			2
		);
	}

	private function check_images_oversized() {
		$imgs = $this->xpath->query( '//img[@src]' );
		$checked   = 0;
		$oversized = 0;
		$max_check = 8; // avoid hammering remote servers with too many HEAD requests

		foreach ( $imgs as $img ) {
			if ( $checked >= $max_check ) {
				break;
			}
			$src = $img->getAttribute( 'src' );
			if ( ! $src || 0 === strpos( $src, 'data:' ) ) {
				continue;
			}
			$src = self::to_absolute_url( $src );
			$response = wp_remote_head( $src, array( 'timeout' => 4 ) );
			if ( is_wp_error( $response ) ) {
				continue;
			}
			$checked++;
			$length = wp_remote_retrieve_header( $response, 'content-length' );
			if ( $length && ( (int) $length / 1024 ) > (int) $this->settings['max_image_kb'] ) {
				$oversized++;
			}
		}

		if ( 0 === $checked ) {
			return null;
		}

		if ( 0 === $oversized ) {
			return $this->result(
				'img_weight', __( 'Image File Sizes', 'mobilytics' ), 'images', 'passed',
				sprintf( __( 'Sampled %d image(s); none exceeded %d KB.', 'mobilytics' ), $checked, (int) $this->settings['max_image_kb'] ),
				__( 'Large images are the single biggest cause of slow mobile page loads.', 'mobilytics' ),
				'', 3
			);
		}

		return $this->result(
			'img_weight', __( 'Image File Sizes', 'mobilytics' ), 'images', $oversized > 2 ? 'critical' : 'warning',
			sprintf( __( '%1$d of %2$d sampled images exceed %3$d KB.', 'mobilytics' ), $oversized, $checked, (int) $this->settings['max_image_kb'] ),
			__( 'Oversized images slow down mobile page loads, especially on cellular connections, and hurt Core Web Vitals.', 'mobilytics' ),
			__( 'Compress images (WebP/AVIF where possible), enable lazy-loading, and use a responsive image/CDN plugin so mobile devices download appropriately-sized files.', 'mobilytics' ),
			3
		);
	}

	// -----------------------------------------------------------------
	// PERFORMANCE
	// -----------------------------------------------------------------

	private function check_render_blocking_resources() {
		$blocking = 0;

		foreach ( $this->xpath->query( '//head//script[@src]' ) as $script ) {
			if ( ! $script->hasAttribute( 'async' ) && ! $script->hasAttribute( 'defer' ) ) {
				$blocking++;
			}
		}
		$css_count = $this->xpath->query( '//head//link[@rel="stylesheet"]' )->length;

		$total_blocking = $blocking + $css_count;

		if ( $total_blocking <= 4 ) {
			return $this->result(
				'render_blocking', __( 'Render-Blocking Resources', 'mobilytics' ), 'performance', 'passed',
				sprintf( __( 'Only %d render-blocking resource(s) found in <head>.', 'mobilytics' ), $total_blocking ),
				__( 'Render-blocking scripts/styles delay when mobile visitors first see content, especially on slower connections.', 'mobilytics' ),
				'', 2
			);
		}

		return $this->result(
			'render_blocking', __( 'Render-Blocking Resources', 'mobilytics' ), 'performance', $total_blocking > 10 ? 'critical' : 'warning',
			sprintf( __( '%1$d render-blocking script(s)/stylesheet(s) found in <head> (%2$d unasync scripts, %3$d stylesheets).', 'mobilytics' ), $total_blocking, $blocking, $css_count ),
			__( 'Each blocking resource delays first paint. On mobile networks this can add seconds before anything is visible.', 'mobilytics' ),
			__( 'Add async/defer to non-critical scripts, combine/minify CSS, and consider a caching or performance plugin to automate this.', 'mobilytics' ),
			2
		);
	}

	private function check_dom_element_count() {
		$count = $this->xpath->query( '//*' )->length;
		$limit = (int) $this->settings['max_elements'];

		if ( $count <= $limit ) {
			return $this->result(
				'dom_size', __( 'Page Complexity (DOM Size)', 'mobilytics' ), 'performance', 'passed',
				sprintf( __( 'Page contains %1$d elements (under the %2$d threshold).', 'mobilytics' ), $count, $limit ),
				__( 'A leaner DOM renders and scrolls more smoothly on lower-powered mobile devices.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'dom_size', __( 'Page Complexity (DOM Size)', 'mobilytics' ), 'performance', $count > $limit * 1.5 ? 'critical' : 'warning',
			sprintf( __( 'Page contains %1$d elements, above the %2$d threshold.', 'mobilytics' ), $count, $limit ),
			__( 'Very large DOM trees slow down rendering and scrolling, particularly on mid-range and older mobile devices.', 'mobilytics' ),
			__( 'Simplify page-builder markup, reduce nested containers/widgets, and paginate or lazy-load long lists of content.', 'mobilytics' ),
			1
		);
	}

	private function check_page_weight() {
		$bytes = strlen( $this->html );
		$kb    = round( $bytes / 1024 );

		if ( $kb <= 500 ) {
			return $this->result(
				'html_weight', __( 'HTML Document Size', 'mobilytics' ), 'performance', 'passed',
				sprintf( __( 'HTML document is %d KB.', 'mobilytics' ), $kb ),
				__( 'Smaller HTML downloads and parses faster on mobile connections.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'html_weight', __( 'HTML Document Size', 'mobilytics' ), 'performance', $kb > 1000 ? 'critical' : 'warning',
			sprintf( __( 'HTML document is %d KB, larger than ideal.', 'mobilytics' ), $kb ),
			__( 'A bloated HTML document (often from page builders) takes longer to download and parse on mobile networks.', 'mobilytics' ),
			__( 'Reduce nested shortcodes/widgets, remove unused page-builder markup, and enable HTML/GZIP compression at the server level.', 'mobilytics' ),
			1
		);
	}

	// -----------------------------------------------------------------
	// NAVIGATION
	// -----------------------------------------------------------------

	private function check_nav_menu_size() {
		$top_items = $this->xpath->query( '//nav//ul[1]/li | //*[contains(concat(" ", normalize-space(@class), " "), " menu ")]/li' );
		$count = $top_items->length;

		if ( 0 === $count ) {
			return null;
		}

		if ( $count <= 7 ) {
			return $this->result(
				'nav_size', __( 'Navigation Menu Size', 'mobilytics' ), 'navigation', 'passed',
				sprintf( __( 'Primary navigation has approximately %d top-level items.', 'mobilytics' ), $count ),
				__( 'A concise menu is easier to scan and tap on a small screen.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'nav_size', __( 'Navigation Menu Size', 'mobilytics' ), 'navigation', $count > 12 ? 'critical' : 'warning',
			sprintf( __( 'Primary navigation has approximately %d top-level items.', 'mobilytics' ), $count ),
			__( 'Long menus become a scrolling wall of links inside a mobile hamburger menu, making it harder for visitors to find what they need.', 'mobilytics' ),
			__( 'Group related links into dropdown sub-menus and keep top-level navigation to 5–7 key destinations.', 'mobilytics' ),
			1
		);
	}

	private function check_hamburger_present() {
		$pattern = '/(menu-toggle|hamburger|mobile-menu|nav-toggle|menu-icon|aria-label=["\'][^"\']*menu[^"\']*["\'])/i';
		if ( preg_match( $pattern, $this->html ) ) {
			return $this->result(
				'hamburger_menu', __( 'Mobile Menu Pattern', 'mobilytics' ), 'navigation', 'passed',
				__( 'A mobile menu toggle ("hamburger" pattern) was detected.', 'mobilytics' ),
				__( 'A dedicated mobile menu keeps navigation usable when there is not enough horizontal space for a full menu bar.', 'mobilytics' ),
				'', 2
			);
		}
		return $this->result(
			'hamburger_menu', __( 'Mobile Menu Pattern', 'mobilytics' ), 'navigation', 'warning',
			__( 'No mobile menu toggle pattern was detected in the markup.', 'mobilytics' ),
			__( 'Without a collapsible menu, a full desktop navigation bar can overflow, wrap awkwardly, or become unreadable on small screens.', 'mobilytics' ),
			__( 'Use a theme with a built-in responsive/mobile menu, or add a menu plugin that collapses navigation into a hamburger icon under a set breakpoint.', 'mobilytics' ),
			2
		);
	}

	// -----------------------------------------------------------------
	// ACCESSIBILITY
	// -----------------------------------------------------------------

	private function check_form_inputs() {
		$inputs = $this->xpath->query( '//input[@type!="hidden"] | //textarea | //select' );
		$total  = $inputs->length;
		$unlabeled = 0;

		foreach ( $inputs as $input ) {
			$id = $input->getAttribute( 'id' );
			$has_label = false;
			if ( $id ) {
				$label = $this->xpath->query( '//label[@for="' . $id . '"]' );
				$has_label = $label->length > 0;
			}
			$has_aria = $input->hasAttribute( 'aria-label' ) || $input->hasAttribute( 'aria-labelledby' ) || $input->hasAttribute( 'placeholder' );
			if ( ! $has_label && ! $has_aria ) {
				$unlabeled++;
			}
		}

		if ( 0 === $total ) {
			return null;
		}

		if ( 0 === $unlabeled ) {
			return $this->result(
				'form_labels', __( 'Form Field Labels', 'mobilytics' ), 'accessibility', 'passed',
				__( 'All form fields have an associated label or accessible name.', 'mobilytics' ),
				__( 'Labels tell mobile screen-reader users (and autofill) what each field is for; tapping a label also expands the tappable area.', 'mobilytics' ),
				'', 2
			);
		}

		return $this->result(
			'form_labels', __( 'Form Field Labels', 'mobilytics' ), 'accessibility', $unlabeled > 2 ? 'critical' : 'warning',
			sprintf( __( '%1$d of %2$d form field(s) have no associated label, aria-label, or placeholder.', 'mobilytics' ), $unlabeled, $total ),
			__( 'Unlabeled fields are confusing for screen-reader users and reduce the tappable area to just the input box itself.', 'mobilytics' ),
			__( 'Add a <label for="field-id"> for every input, or at minimum an aria-label attribute.', 'mobilytics' ),
			2
		);
	}

	private function check_popup_indicators() {
		$pattern = '/(class=["\'][^"\']*(popup|modal|lightbox|interstitial|subscribe-overlay)[^"\']*["\'])/i';
		if ( preg_match_all( $pattern, $this->html, $m ) ) {
			$count = count( $m[0] );
			return $this->result(
				'popups', __( 'Intrusive Popups', 'mobilytics' ), 'accessibility', $count > 2 ? 'warning' : 'warning',
				sprintf( __( 'Detected markup for %d popup/modal/overlay element(s).', 'mobilytics' ), $count ),
				__( "Google's mobile-friendly guidelines flag intrusive interstitials that cover content immediately on page load, and they frustrate visitors on small screens where a close button (X) can be hard to tap.", 'mobilytics' ),
				__( 'Ensure any popup has a large, easy-to-tap close button, does not appear immediately on page load, and does not cover the main content or block reading on mobile.', 'mobilytics' ),
				2
			);
		}
		return $this->result(
			'popups', __( 'Intrusive Popups', 'mobilytics' ), 'accessibility', 'passed',
			__( 'No popup/modal/overlay markup patterns detected.', 'mobilytics' ),
			__( 'Intrusive interstitials that appear immediately are a common mobile UX and SEO penalty.', 'mobilytics' ),
			'', 2
		);
	}

	private function check_tap_highlight_and_zoom() {
		// Soft accessibility check: ensure text isn't set via -webkit-text-size-adjust:none, which
		// can prevent legitimate browser text-resizing on mobile.
		if ( preg_match( '/-webkit-text-size-adjust\s*:\s*none/i', $this->html ) ) {
			return $this->result(
				'text_resize', __( 'Text Resize Allowed', 'mobilytics' ), 'accessibility', 'warning',
				__( 'CSS disables automatic text resizing (-webkit-text-size-adjust: none).', 'mobilytics' ),
				__( 'This can prevent mobile browsers and users from resizing text for readability, an accessibility concern.', 'mobilytics' ),
				__( 'Remove -webkit-text-size-adjust: none unless you have a specific, tested reason to keep it.', 'mobilytics' ),
				1
			);
		}
		return $this->result(
			'text_resize', __( 'Text Resize Allowed', 'mobilytics' ), 'accessibility', 'passed',
			__( 'Text resizing is not disabled.', 'mobilytics' ),
			__( 'Allowing text resize supports users who need larger text for readability.', 'mobilytics' ),
			'', 1
		);
	}

	// -----------------------------------------------------------------
	// MOBILE SEO
	// -----------------------------------------------------------------

	private function check_cta_clarity() {
		$generic_terms = array( 'click here', 'read more', 'submit', 'learn more', 'here' );
		$links = $this->xpath->query( '//a | //button' );
		$generic = 0;
		$total   = 0;

		foreach ( $links as $link ) {
			$text = strtolower( trim( wp_strip_all_tags( $link->textContent ) ) );
			if ( '' === $text ) {
				continue;
			}
			$total++;
			if ( in_array( $text, $generic_terms, true ) ) {
				$generic++;
			}
		}

		if ( 0 === $total ) {
			return null;
		}

		$ratio = $generic / $total;

		if ( $ratio < 0.15 ) {
			return $this->result(
				'cta_clarity', __( 'Clear Calls-to-Action', 'mobilytics' ), 'mobile_seo', 'passed',
				__( 'Most buttons/links use descriptive text.', 'mobilytics' ),
				__( 'Descriptive CTAs ("Download the Guide" vs "Click Here") are easier to scan on mobile and clearer for screen readers, which often list links out of context.', 'mobilytics' ),
				'', 1
			);
		}

		return $this->result(
			'cta_clarity', __( 'Clear Calls-to-Action', 'mobilytics' ), 'mobile_seo', $ratio > 0.35 ? 'critical' : 'warning',
			sprintf( __( '%1$d of %2$d link(s)/button(s) use generic text like "click here" or "read more".', 'mobilytics' ), $generic, $total ),
			__( 'Generic CTA text is harder to scan quickly on a small screen and provides no context to screen-reader users navigating by links list.', 'mobilytics' ),
			__( 'Rewrite CTAs to describe the destination or action, e.g. "View Pricing" instead of "Click Here".', 'mobilytics' ),
			1
		);
	}

	private function check_meta_title_description() {
		$title_nodes = $this->xpath->query( '//title' );
		$title = $title_nodes->length ? trim( $title_nodes->item( 0 )->textContent ) : '';
		$desc_nodes = $this->xpath->query( '//meta[@name="description"]' );
		$desc = $desc_nodes->length ? trim( $desc_nodes->item( 0 )->getAttribute( 'content' ) ) : '';

		$issues = array();
		if ( '' === $title ) {
			$issues[] = __( 'missing <title>', 'mobilytics' );
		} elseif ( mb_strlen( $title ) > 60 ) {
			$issues[] = __( 'title longer than 60 characters (may truncate on mobile search results)', 'mobilytics' );
		}
		if ( '' === $desc ) {
			$issues[] = __( 'missing meta description', 'mobilytics' );
		} elseif ( mb_strlen( $desc ) > 160 ) {
			$issues[] = __( 'meta description longer than 160 characters (may truncate on mobile search results)', 'mobilytics' );
		}

		if ( empty( $issues ) ) {
			return $this->result(
				'meta_tags', __( 'Title & Meta Description', 'mobilytics' ), 'mobile_seo', 'passed',
				__( 'Title and meta description are present and appropriately sized for mobile search results.', 'mobilytics' ),
				__( 'Mobile search results show less text than desktop, so concise, well-sized titles/descriptions matter more.', 'mobilytics' ),
				'', 2
			);
		}

		return $this->result(
			'meta_tags', __( 'Title & Meta Description', 'mobilytics' ), 'mobile_seo', 'warning',
			implode( '; ', $issues ) . '.',
			__( 'Mobile search results truncate long titles/descriptions more aggressively than desktop, and missing tags hurt click-through rate.', 'mobilytics' ),
			__( 'Use an SEO plugin (e.g. Yoast, Rank Math) to set a title under 60 characters and a meta description under 160 characters for every page.', 'mobilytics' ),
			2
		);
	}

	private function check_lang_attribute() {
		$html_nodes = $this->xpath->query( '//html[@lang]' );
		if ( $html_nodes->length > 0 ) {
			return $this->result(
				'lang_attr', __( 'Language Declared', 'mobilytics' ), 'mobile_seo', 'passed',
				__( 'The <html> tag declares a language.', 'mobilytics' ),
				__( 'Declaring language helps mobile search engines and screen readers serve the right audience and pronunciation.', 'mobilytics' ),
				'', 1
			);
		}
		return $this->result(
			'lang_attr', __( 'Language Declared', 'mobilytics' ), 'mobile_seo', 'warning',
			__( 'The <html> tag has no lang attribute.', 'mobilytics' ),
			__( 'Search engines and assistive technology use this to determine content language.', 'mobilytics' ),
			__( 'WordPress sets this automatically via language_attributes() in header.php — confirm your theme calls it.', 'mobilytics' ),
			1
		);
	}

	// -----------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------

	private function result( $id, $label, $category, $status, $message, $why, $fix, $weight = 1 ) {
		return array(
			'id'       => $id,
			'label'    => $label,
			'category' => $category,
			'status'   => $status,
			'message'  => $message,
			'why'      => $why,
			'fix'      => $fix,
			'weight'   => $weight,
			'source'   => 'server',
		);
	}

	public static function to_absolute_url( $src ) {
		if ( preg_match( '#^https?://#i', $src ) ) {
			return $src;
		}
		if ( 0 === strpos( $src, '//' ) ) {
			return ( is_ssl() ? 'https:' : 'http:' ) . $src;
		}
		return home_url( $src );
	}
}
