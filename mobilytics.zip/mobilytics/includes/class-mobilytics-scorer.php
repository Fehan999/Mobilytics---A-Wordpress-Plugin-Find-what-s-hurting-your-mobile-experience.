<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobilytics_Scorer
 *
 * Turns a flat list of check results into category scores and an overall
 * 0-100 score, using each check's weight as its relative importance.
 */
class Mobilytics_Scorer {

	/** Canonical category order + display labels. */
	public static function categories() {
		return array(
			'responsive'     => __( 'Responsive Design', 'mobilytics' ),
			'readability'    => __( 'Readability', 'mobilytics' ),
			'touch_targets'  => __( 'Touch Targets', 'mobilytics' ),
			'navigation'     => __( 'Navigation', 'mobilytics' ),
			'images'         => __( 'Images', 'mobilytics' ),
			'performance'    => __( 'Performance', 'mobilytics' ),
			'accessibility'  => __( 'Accessibility', 'mobilytics' ),
			'mobile_seo'     => __( 'Mobile SEO', 'mobilytics' ),
		);
	}

	private static function status_points( $status ) {
		switch ( $status ) {
			case 'passed':
				return 100;
			case 'warning':
				return 50;
			case 'critical':
			default:
				return 0;
		}
	}

	/**
	 * @param array $checks Flat array of check result arrays.
	 * @return array {
	 *   overall_score, categories: [ key => [ label, score, passed, warning, critical, checks ] ],
	 *   counts: [ passed, warning, critical, total ]
	 * }
	 */
	public static function score( array $checks ) {
		$labels    = self::categories();
		$grouped   = array_fill_keys( array_keys( $labels ), array() );
		$counts    = array( 'passed' => 0, 'warning' => 0, 'critical' => 0, 'total' => 0 );

		foreach ( $checks as $check ) {
			if ( empty( $check['category'] ) || ! isset( $grouped[ $check['category'] ] ) ) {
				continue;
			}
			$grouped[ $check['category'] ][] = $check;
			$counts['total']++;
			if ( isset( $counts[ $check['status'] ] ) ) {
				$counts[ $check['status'] ]++;
			}
		}

		$category_results = array();
		$category_scores   = array();

		foreach ( $labels as $key => $label ) {
			$items = $grouped[ $key ];
			if ( empty( $items ) ) {
				$category_results[ $key ] = array(
					'label'    => $label,
					'score'    => null, // no checks ran for this category
					'passed'   => 0,
					'warning'  => 0,
					'critical' => 0,
					'checks'   => array(),
				);
				continue;
			}

			$weighted_sum   = 0;
			$weight_total   = 0;
			$p = $w = $c = 0;

			foreach ( $items as $item ) {
				$weight = isset( $item['weight'] ) ? max( 1, (int) $item['weight'] ) : 1;
				$weighted_sum += self::status_points( $item['status'] ) * $weight;
				$weight_total += $weight;

				if ( 'passed' === $item['status'] ) {
					$p++;
				} elseif ( 'warning' === $item['status'] ) {
					$w++;
				} else {
					$c++;
				}
			}

			$score = $weight_total > 0 ? round( $weighted_sum / $weight_total ) : null;
			$category_results[ $key ] = array(
				'label'    => $label,
				'score'    => $score,
				'passed'   => $p,
				'warning'  => $w,
				'critical' => $c,
				'checks'   => $items,
			);
			if ( null !== $score ) {
				$category_scores[] = $score;
			}
		}

		$overall = ! empty( $category_scores ) ? (int) round( array_sum( $category_scores ) / count( $category_scores ) ) : 0;

		return array(
			'overall_score' => $overall,
			'categories'    => $category_results,
			'counts'        => $counts,
			'grade'         => self::grade_for_score( $overall ),
		);
	}

	public static function grade_for_score( $score ) {
		$settings = Mobilytics_Settings::get();
		$good     = (int) $settings['threshold_good'];
		$warning  = (int) $settings['threshold_warning'];

		if ( $score >= $good ) {
			return array( 'label' => __( 'Good', 'mobilytics' ), 'status' => 'passed' );
		}
		if ( $score >= $warning ) {
			return array( 'label' => __( 'Needs Work', 'mobilytics' ), 'status' => 'warning' );
		}
		return array( 'label' => __( 'Critical', 'mobilytics' ), 'status' => 'critical' );
	}
}
